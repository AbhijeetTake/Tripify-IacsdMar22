import React from "react";
import ScheduleTbl from "../../components/tables/tblSchedule/ScheduleTbl";
import "./SchedulesStyle.css";

export const SchedulesPage = () => {
  return (
    <div id="schedule-page">
      <h1>HAVE U SET SCHEDULES YET?!!</h1>
      <ScheduleTbl />
    </div>
  );
};
