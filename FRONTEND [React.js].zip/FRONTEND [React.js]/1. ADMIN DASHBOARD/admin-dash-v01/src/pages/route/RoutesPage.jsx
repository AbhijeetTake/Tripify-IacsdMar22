import React from "react";
import "./RoutesPage.css";
import { PacmanSpinner } from "../../components/spinners/Spinner";
import Ticket from "../../components/ticket/Ticket";
import RoutesTbl from "../../components/tables/tblRoute/RoutesTbl";
// import RoutesTable from "./RoutesTable";
export const RoutesPage = () => {
  return (
    <div id="rt-page-container">
      {/* <PacmanSpinner/> */}
      {/* <Ticket></Ticket> */}
      <h1>ALL AVAILABLE ROUTES</h1>
      <RoutesTbl />
    </div>
  );
};
