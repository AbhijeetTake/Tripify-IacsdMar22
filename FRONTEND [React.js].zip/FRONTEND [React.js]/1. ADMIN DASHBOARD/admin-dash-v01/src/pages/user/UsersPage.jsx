import React from "react";
import UserTbl from "../../components/tables/tblUser/UserTbl";
import { Payment } from "../payment/Payment";
export const UsersPage = () => {
  return (
    <div id="flight-page">
      <h1>welcome to Users database</h1>
      <UserTbl />
    </div>
  );
};
