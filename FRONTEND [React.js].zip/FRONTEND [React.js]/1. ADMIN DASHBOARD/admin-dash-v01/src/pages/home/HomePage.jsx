import React, { useEffect } from "react";
import { useState } from "react";
import axios from "axios";
import "./HomeStyle.css";
import { AirlineCardData, InfoCardData } from "../../components/card/CardData";
import { InfoCard } from "../../components/card/InfoCard";
import Modal from "../../components/popups/Modal";
// REMOVE THIS

export const HomePage = () => {
  const [openModel, setOpenModel] = useState(false); // store popup open boolean
  // for cards data from api
  const [userCount, setUserCount] = useState(0);
  const [routeCount, setRouteCount] = useState(0);
  const [flightCount, setFlightCount] = useState(0);
  const [scheduleCount, setScheduleCount] = useState(0);
  const [totRevenue, setTotRevenue] = useState(0.0);

  // making array of state variable to use
  const countValues = [userCount, routeCount, flightCount, scheduleCount,totRevenue];
  //--------------  getting value ----------------------
  useEffect(() => {
    // user length
    axios
      .get(`http://localhost:63301/api/Home`)
      .then((res) => {
        setUserCount(res.data.length);
      })
      .catch((err) => console.log(""));

    // route length
    axios
      .get(`http://localhost:63301/api/Routes`)
      .then((res) => {
        setRouteCount(res.data.length);
        console.log("routes length" + res.data.length);
      })
      .catch((err) => console.log(""));

    // flight length
    axios
      .get(`http://localhost:63301/api/Flights`)
      .then((res) => {
        setFlightCount(res.data.length);
      })
      .catch((err) => console.log(""));

    // schedule length
    axios
      .get(`http://localhost:63301/api/Schedules/`)
      .then((res) => {
        setScheduleCount(res.data.length);
      })
      .catch((err) => console.log(""));

    // total revenue length
    axios
      .get(`http://localhost:63301/api/Payments/`)
      .then((res) => {
        
        console.log("amount" + res.data.length);
        res.data.map((item, index) => {
          setTotRevenue(item.Amount + totRevenue);
        });
        console.log("revenue => " + totRevenue);
      })
      .catch((err) => console.log(""));
  }, [userCount, routeCount, flightCount, scheduleCount]);

  return (
    <div id="hm-page">
      {/* ------------------ left-side-page ------------------ */}
      <div id="hm-main-container">
        {/* title in home page */}
        <div id="hm-main-title">
          <h1>Hello Admin😀</h1>
        </div>
        <br />
        {/*TODO: AIRLINE CARDS */}
        {/* <div className="hm-al-cards-container">
          {AirlineCardData.map((obj, index) => {
            return <h2>airline cards</h2>;
          })}
        </div> */}

        {/* INFO CARDS */}
        <div id="hm-info-cards-container">
          {InfoCardData.map((obj, index) => {
            return (
              <InfoCard
                key={index}
                title={obj.title}
                color={obj.color}
                icon={obj.icons}
                barValue={obj.barValue}
                value={countValues[index]}
                series={obj.series}
              />
            );
          })}
        </div>
      </div>
      {/* ----------------- right side page ------------------- */}
      <div id="hm-side-container"></div>
      {/* closePopup : is a fn reference passed to child i.e Modal so that from child this fn can be used */}
      <Modal openPopup={openModel} closePopup={() => setOpenModel(false)}>
        <p>hello world</p>
      </Modal>
    </div>
  );
};
