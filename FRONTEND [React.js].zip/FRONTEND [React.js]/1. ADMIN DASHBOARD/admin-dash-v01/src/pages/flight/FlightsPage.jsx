import React from "react";
import "./FlightStyles.css";
import FlightTbl from "../../components/tables/tblFlight/FlightTbl";

export const FlightsPage = () => {
  return (
    <div id="ft-page">
      <h1 id="ft">ALL AVAILABLE FLIGHTS</h1>
      <FlightTbl />
    </div>
  );
};
