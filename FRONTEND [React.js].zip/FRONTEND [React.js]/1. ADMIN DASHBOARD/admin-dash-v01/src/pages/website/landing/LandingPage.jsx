import React from 'react'

function LandingPage() {
  return (
    <div>landingPage</div>
  )
}

export default LandingPage