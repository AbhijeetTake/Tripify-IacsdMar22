import React, { useState } from "react";
import "./NoMatchStyle.css";
// -------------------------------------------------------------------
// for pop-up
import Modal404 from "../../components/popups/Modal404";
// -------------------------------------------------------------------

export const NoMatchPage = () => {
  return <Modal404></Modal404>;
};
