import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export const ProtectedPages = ({ ValidatePage }) => {
  // useNavigate HOOK TO navigate user based on his correct credential
  const navigateTo = useNavigate();
  useEffect(() => {
    // GET KEY-VALUE FROM LOCALSTORAGE
    let token = JSON.parse(localStorage.getItem("token"));
    token == null || undefined
      ? navigateTo("/login")
      : // alert("NOT LOGGED IN");
        console.log("token avaiable: " + token);
  });

  return (
    <div>
      {/* ALL PAGES WILL BE SHOWN HERE */}
      <ValidatePage />
    </div>
  );
};
