import React, { useState } from "react";
import Modal from "../../components/popups/Modal";
import "./LoginPage.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
// --------------------------------------------------------------------
// toast notifications
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
// --------------------------------------------------------------------

export const LoginPage = () => {
  const Navigate = useNavigate();
  const [form_Message, setForm_Message] = useState("");
  const [msgColor, setMsgColor] = useState("Red");
  const [openLoginPopup, setOpenLoginPopup] = useState(true);

  const [DataItem, setDataItem] = useState({
    User_id: "0",
    Email: "",
    Password: "",
    confirmpwd: "",
    Phone_nu: "",
    Address: "",
    Role: "ADMIN",
    returnUrl: "",
  });

  const submitRegistrationDetails = (e) => {
    const LoginUrl = `http://localhost:63301/api/Home/`;
    axios
      .post(LoginUrl, DataItem)
      .then((Response) => {
        toast.success("WELCOME BACK🤩");
        console.log(Response.data);
        // for messages
        setForm_Message("Success");
        setMsgColor("Green");
        // set token for current login
        localStorage.setItem("token", JSON.stringify(Response.data));
        // wait for 1 sec to send msg
        setTimeout(() => Navigate("/"), 1500);
      })
      .catch((Response) => {
        toast.error("FAILED TO LOG-IN😭");
        console.log(Response.data);
        setForm_Message("Invalid User Name or Password");
      });

    e.preventDefault();
  };

  const handleInputChangeEvent = (e) => {
    const newDataItem = { ...DataItem };
    newDataItem[e.target.name] = e.target.value;
    setDataItem(newDataItem);
  };

  return (
    <Modal
      openPopup={openLoginPopup}
      closePopup={() => setOpenLoginPopup(false)}
      iconStyles={{ display: "none" }}
      dialogBoxStyles={{
        width: "100%",
        height: "100vh",
        backgroundImage: " linear-gradient(to top, #c71d6f 0%, #d09693 100%)",
      }}
    >
      <div className="login-pg-admin">
        <div id="shape-1"></div>
        <div id="shape-2"></div>
        <div id="login-col-1">
          <h2>Welcome to Tripify</h2>
          <p>Sign-In and Enjoy the Service</p>
          <form
            method="POST"
            id="form-login"
            className="flex flex-col-1"
            onSubmit={(e) => submitRegistrationDetails(e)}
          >
            <label htmlFor="Email">
              <span>EMAIL</span>
              <input
                type="text"
                name="Email"
                onChange={(e) => handleInputChangeEvent(e)}
                placeholder="emailID"
              />
            </label>

            <label htmlFor="Password">
              <span>PASSWORD</span>
              <input
                type="password"
                name="Password"
                onChange={(e) => handleInputChangeEvent(e)}
                placeholder="password"
              />
            </label>

            <button id="btn-login">LOG-IN</button>
          </form>

          <h5 style={{ color: `${msgColor}` }}>
            <br />
            {form_Message}
          </h5>
        </div>

        <div id="login-col-2">{/* <img src={bgImg} alt="" /> */}</div>
      </div>
      {/* Toast notification container required to show toast notification */}
      <ToastContainer theme="colored" autoClose={1500} />
    </Modal>
  );
};
