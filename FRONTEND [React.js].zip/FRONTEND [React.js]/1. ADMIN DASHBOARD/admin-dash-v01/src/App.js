import "./App.css";
import SideBar from "./components/sidebar/SideBar";
import { RoutesConfig } from "./routes/RoutesConfig";

function App() {
  return (
    <div className="App">
      <div className="Main">
        <SideBar>
          <RoutesConfig />
        </SideBar>
      </div>
    </div>
  );
}

export default App;
