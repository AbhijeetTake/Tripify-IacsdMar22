import React, { useState, useEffect } from "react";
import axios from "axios";
// for date converter
import { DateFormatConverter } from "../../../utils/DateFormatConverter";
import { TableColData } from "../../../data/TableColData";
import { BounceLoader } from "react-spinners";
import { PacmanSpinner } from "../../../components/spinners/Spinner";
import "./UserTbl.css";
import { BsFillCaretDownFill } from "react-icons/bs";
// icons
import { AiFillAlert } from "react-icons/ai";

import Modal from "../../popups/Modal";
// --------------------------------------------------------------------
// toast notifications
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
// --------------------------------------------------------------------

function UserTbl() {
  const [loading, setLoading] = useState(false); // stores spinner loading condition
  const [routes, setRoutes] = useState([]); // stores GET data from API
  const [openModel, setOpenModel] = useState(false); // store popup open boolean
  const [openUpdateModel, setOpenUpdateModel] = useState(false); // store popup open boolean
  // store routeId of table row whos EDIT | DELETE btn is clicked
  // using same form we will perform ADD-NEW-ROUTE (OR) UPDATE ROUTE
  //  routeId === 0 ? "ADD NEW ROUTE" : "UPDATE ROUTE";
  const [routeId, setRouteId] = useState(0);

  //------------ FUNCTION TO FETCH DATA FROM API ------------
  const callGetAllRoutesAPI = () => {
    axios
      .get("http://localhost:63301/api/Home")
      .then((res) => {
        // console.log(res.data);
        setRoutes(res.data);
        setLoading(false);
      })
      .catch((err) => console.log(err));
  };

  // ------------ function & handler to delete ------------
  const openDeleteModel = (id) => {
    setRouteId(id);
    setOpenModel(true);
  };
  const handleBtnAction = (routeId) => {
    // store API for DELETE_BY_ID
    const delAPI = `http://localhost:63301/api/Home`;

    axios
      .put(delAPI, {
        User_id: routeId,
      })
      .then((res) => {
        callGetAllRoutesAPI();
        toast.success("sucessfully Disabled user😁");
      })
      .catch((err) => {
        console.log(err);
        toast.error("user Failed to Disable😣");
      });
    setOpenModel(false);
  };

  useEffect(() => {
    setLoading(true);
    // call fn to fetch data from API
    callGetAllRoutesAPI();
  }, [routes.length]);

  return (
    <div>
      {/* -------------- modal / pop-ups FOR DELETE WARING --------------- */}
      <Modal
        id="del-warn-popup"
        openPopup={openModel}
        closePopup={() => setOpenModel(false)}
        // pass icon CSSstyles-obj as props
        icon={<AiFillAlert size={32} />}
        iconStyles={{ backgroundColor: "#f1c40f" }}
        //  pass dialog-box CSSstyles-obj as props
        dialogBoxStyles={{
          width: "20rem",
          height: "13rem",
          borderRadius: "1rem",
          backgroundColor: "#f1f2f6",
        }}
      >
        <h1 id="popup-heading">Are you Sure🙄?</h1>
        <div className="popup-btns">
          <button
            id="alert-delete-btn"
            onClick={() => {
              console.log("clicked popup delete", handleBtnAction(routeId));
            }}
          >
            💀DISABLE
          </button>
          <button id="alert-cancel-btn" onClick={() => setOpenModel(false)}>
            😷NO...
          </button>
        </div>
      </Modal>
      {/* --------- spinners --------- */}
      <PacmanSpinner loading={loading} />
      <BounceLoader id="spinner-loader" loading={loading} />

      <div id="route-tbl-row1">
        <h3> </h3>
      </div>
      <div id="route-tbl-row2">
        <table>
          {/* ------------ table columns -------------- */}
          <thead>
            <tr>
              {TableColData.userTbl.map((item, index) => {
                return (
                  <th key={index}>
                    {item}
                    <BsFillCaretDownFill />
                  </th>
                );
              })}
            </tr>
          </thead>
          {/* -------------- table rows data from backend ------------- */}
          <tbody>
            {routes.map((route, index) => (
              // return each obj[in JSON array] mapped as JSX in format below

              <tr key={route.User_id}>
                <td>{route.User_id}</td>
                <td id="tbl-fullname">
                  {route.First_name} {route.Last_name}
                </td>
                <td>{route.Email}</td>
                <td>{route.Phone_nu}</td>
                <td>{route.Address}</td>

                <td>
                  {/* TABLE DISABLE btn */}
                  <button
                    id="rt-delete-btn"
                    onClick={() => openDeleteModel(route.User_id)}
                  >
                    <span>❌Disable</span>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Toast notification container required to show toast notification */}
        <ToastContainer theme="colored" autoClose={1500} />
      </div>
    </div>
  );
}

export default UserTbl;
