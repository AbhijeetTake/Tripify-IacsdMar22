import React, { useState, useEffect } from "react";
import axios from "axios";
// for date converter
import { DateFormatConverter } from "../../../utils/DateFormatConverter";
import { TableColData } from "../../../data/TableColData";
import { BounceLoader } from "react-spinners";
import { PacmanSpinner } from "../../../components/spinners/Spinner";
import "./ScheduleTbl.css";
import { AiFillEdit } from "react-icons/ai";
import { AiFillDelete } from "react-icons/ai";
import { BsFillCaretDownFill } from "react-icons/bs";
// icons
import { AiFillAlert } from "react-icons/ai";
import { ImPencil2 } from "react-icons/im";
import { BsArrowRight } from "react-icons/bs";

import Modal from "../../popups/Modal";
// --------------------------------------------------------------------
// toast notifications
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
// --------------------------------------------------------------------

function ScheduleTbl() {
  const [loading, setLoading] = useState(false); // stores spinner loading condition
  const [routes, setRoutes] = useState([]); // stores GET data from API
  const [dropDownRoutes, setDropDownRoutes] = useState([]);
  const [dropDownSelectedValue, setDropDownSelectedValue] = useState(0); // initially routid=1 in dropdown
  const [airLineDropDownSelectedValue, setAirLineDropDownSelectedValue] =
    useState("");
  const [openModel, setOpenModel] = useState(false); // store popup open boolean
  const [openUpdateModel, setOpenUpdateModel] = useState(false); // store popup open boolean
  // store flightId of table row whos EDIT | DELETE btn is clicked
  // using same form we will perform ADD-NEW-ROUTE (OR) UPDATE ROUTE
  //  flightId === 0 ? "ADD NEW ROUTE" : "UPDATE ROUTE";
  const [flightId, setflightId] = useState(0);

  // stores new data from ADMIN
  // keep name same as Form input-name
  const initialValue = {
    Schedule_id: 0,
    Flight_Id: 0,
    Departure_Date: "",
    Departure_Time: "",
    Arrival_Time: "",
  };
  const [itemByID, setItemByID] = useState(initialValue); // stores new flight data added by admin

  //------------ FUNCTION TO FETCH DATA FROM API ------------
  const callGetAllFlightsAPI = () => {
    axios
      .get("http://localhost:63301/api/Schedules")
      .then((res) => {
        // console.log("schedules: "+res);
        setRoutes(res.data);
        setLoading(false);
      })
      .catch((err) => console.log(err));
  };

  // ------------ FUNCTION & HANDLER TO ADD NEW flight  ----------
  const handleModalAddBtn = () => {
    axios
      .post(`http://localhost:63301/api/Schedules`, itemByID)
      .then((res) => {
        console.log(res);
        setOpenUpdateModel(false);
        callGetAllFlightsAPI();
        toast.success("route sucessfully ADDED✨");
      })
      .catch((err) => {
        console.log(err);
        toast.error("FAILED TO ADD NEW FLIGHT😭");
      });
  };

  // ------------ FUNCTION & HANDLER TO UPDATE ----------

  const updateRoute = (id) => {
    setflightId(id);
    // store on id or which row we are working
    const SdByID = routes.filter(FindScheduleById);
    // SdByID.length
    //   ? setItemByID(SdByID[0])
    //   : console.log("failed to get Schedule by Id");
    if (SdByID.length > 0) {
      console.log(SdByID[0]);
      setItemByID(SdByID[0]);
      setOpenUpdateModel(true);
    } else {
      // toast.error("FAILED TO GET SCHEDULE DATA by Id😭");
      console.log("failed to get Schedule by Id");
    }
    // setOpenUpdateModel(true);
  };
  function FindScheduleById(scheduleObj) {
    return scheduleObj.Schedule_ID == flightId;

    // if (scheduleObj.Schedule_ID == flightId) {
    //   // const getByIdAPI = `http://localhost:63301/api/Schedules`;
    //   // console.log("flight id is:" + id);
    //   console.log("schedule"+ scheduleObj);
    //   setItemByID(scheduleObj); // store recieved route info
    //   // console.log("data by Id: " + itemByID.BussCap);
    //   // console.log("current route_Id: " + res.data.Route_id);
    //   setOpenUpdateModel(true); // open modal who's form contain this stored-route_info values for editing
    //   setflightId(scheduleObj.Schedule_ID); // hence now AddOrUpdate = update (since flightId NOT 0)
    //   console.log("data to edit: " + itemByID);
    // } else {
    //   console.log("cant find id");
    // }
  }

  // EVENT HANDLER to store data in state: for onChange of text in <input/> call this event
  const handleAddFormChange = (event) => {
    console.log(event);
    // event.preventDefault();
    const { name, value } = event.target;
    // make a copy of state variable containing current route-info for editing
    const newDataItem = { ...itemByID };
    newDataItem[name] = value;

    // now we have state_variable with final data that we can axios.PUT() on "update" click.
    setItemByID(newDataItem);
  };

  const handleModelUpdateBtn = (id) => {
    const apiPUT = `http://localhost:63301/api/Schedules`;

    axios
      .put(apiPUT, itemByID)
      .then((res) => {
        toast.success("Flight sucessfully UPDATED✨");
        console.log("success:" + res);
        setOpenUpdateModel(false);
        callGetAllFlightsAPI();
      })
      .catch((err) => {
        console.log(err);
        toast.error("flight failed to UPDATE😣");
      });
  };

  // ------------ function & handler to delete ------------
  const openDeleteModel = (id) => {
    setflightId(id);
    setOpenModel(true);
  };
  const handleBtnAction = (flightId) => {
    // store API for DELETE_BY_ID
    const delAPI = `http://localhost:63301/api/Schedules/${flightId}`;

    axios
      .delete(delAPI)
      .then((res) => {
        callGetAllFlightsAPI();
        toast.success("sucessfully deleted😁");
      })
      .catch((err) => {
        console.log(err);
        toast.error("Flight Failed to Delete😣");
      });
    setOpenModel(false);
  };

  // -------------- for ROUTES DROP DOWN ----------------
  const GetSrcDestRoutes = () => {
    axios
      .get(`http://localhost:63301/api/Flights`)
      .then((res) => {
        console.log(res.data);
        setDropDownRoutes(res.data);
      })
      .catch((err) => {
        console.log(err.data);
      });
  };
  //   dropdown flight Airline options
  const AirLines = ["select one", "vistara", "air india", "virgin"];

  useEffect(() => {
    setLoading(true);
    // call fn to fetch data from API
    callGetAllFlightsAPI();
    GetSrcDestRoutes();
  }, [routes.length]);

  return (
    <div>
      {/* -------------- modal / pop-ups FOR DELETE WARING --------------- */}
      <Modal
        id="del-warn-popup"
        openPopup={openModel}
        closePopup={() => setOpenModel(false)}
        // pass icon CSSstyles-obj as props
        icon={<AiFillAlert size={32} />}
        iconStyles={{ backgroundColor: "#f1c40f" }}
        //  pass dialog-box CSSstyles-obj as props
        dialogBoxStyles={{
          width: "20rem",
          height: "13rem",
          borderRadius: "1rem",
          backgroundColor: "#f1f2f6",
        }}
      >
        <h1 id="popup-heading">Are you Sure🙄?</h1>
        <div className="popup-btns">
          <button
            id="alert-delete-btn"
            onClick={() => {
              console.log("clicked popup delete", handleBtnAction(flightId));
            }}
          >
            💀Delete
          </button>
          <button id="alert-cancel-btn" onClick={() => setOpenModel(false)}>
            😷NO...
          </button>
        </div>
      </Modal>
      {/* --------- spinners --------- */}
      <PacmanSpinner loading={loading} />
      <BounceLoader id="spinner-loader" loading={loading} />

      <div id="route-tbl-row1">
        <button
          id="addNew-route-btn"
          onClick={() => {
            // set flightId=0 => AddOrUpdate="add"_route
            setDropDownSelectedValue(0);
            setAirLineDropDownSelectedValue("");
            setflightId(0);
            // else shows initial value of this state in controlled form-field
            setItemByID({
              Schedule_id: 0,
              Flight_Id: 0,
              Departure_Date: "",
              Departure_Time: "",
              Arrival_Time: "",
            });
            // now open form pop-up
            setOpenUpdateModel(true);
          }}
        >
          Add New Schedule✨
        </button>
      </div>
      <div id="route-tbl-row2">
        <table>
          {/* ------------ table columns -------------- */}
          <thead>
            <tr>
              {TableColData.scheduleTbl.map((item, index) => {
                return (
                  <th key={index}>
                    {item}
                    <BsFillCaretDownFill />
                  </th>
                );
              })}
            </tr>
          </thead>
          {/* -------------- table rows data from backend ------------- */}
          <tbody>
            {routes.map((route, index) => (
              // return each obj[in JSON array] mapped as JSX in format below

              <tr key={route.Schedule_ID}>
                <td>{route.Schedule_ID}</td>
                <td>{route.Flight_ID}</td>
                <td>{route.Source}</td>
                <td>{route.Destination}</td>
                <DateFormatConverter date={route.DepartureDate} />
                <td>{route.DepartureTime.split("T")[1]}</td>
                <td>{route.ArrivalTime.split("T")[1]}</td>
                {/* <DateFormatConverter date={route.Created_date} /> */}
                <td>
                  {/* form EDIT btn */}
                  <button
                    id="rt-edit-btn"
                    onClick={() => {
                      setDropDownSelectedValue(route.Flight_Id);
                      // setAirLineDropDownSelectedValue(route.Flight_name);
                      console.log(route.Schedule_ID);
                      setflightId(route.Schedule_ID);
                      console.log("==> route obj: " + route.Flight_ID);
                      updateRoute(route.Schedule_ID);
                    }}
                  >
                    <AiFillEdit color="white" />
                  </button>

                  {/* form DELETE btn */}
                  <button
                    id="rt-delete-btn"
                    onClick={() => openDeleteModel(route.Schedule_ID)}
                  >
                    <AiFillDelete color="#34495e" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {/* ------------- modal to update route ----------------- */}
        <Modal
          openPopup={openUpdateModel}
          closePopup={() => setOpenUpdateModel(false)}
          icon={<ImPencil2 size={32} />}
          iconStyles={{ backgroundColor: "#3dc1d3" }}
          dialogBoxStyles={{
            width: "22rem",
            height: "35rem",
            borderRadius: "1rem",
            backgroundColor: "#f1f2f6",
          }}
        >
          {flightId === 0 ? (
            <h1>Add New Schedule🐾</h1>
          ) : (
            <h1>Edit Schedule👀</h1>
          )}

          <form id="update-form-popup">
            {/* <div>
              <select
                id="routes-drop-down-menu"
                // value={initialValue.Route_id}
                name="Route_id"
                onChange={handleAddFormChange}
                defaultValue={dropDownSelectedValue}
              >
                {dropDownRoutes.map((row, index) => {
                  return (
                    <option
                      key={row.Route_id}
                      value={row.Route_id}
                      // selected={row.Route_id}
                    >
                      {row.Route_id}: {row.Source} 👉 {row.Destination}
                    </option>
                  );
                })}
              </select>
            </div> */}
            {/* <input
              className="update-form-field"
              type="text"
              name="Flight_name"
              value={itemByID.Flight_name}
              placeholder="Select AirLine here"
              onChange={handleAddFormChange}
            /> */}
            {/* <div>
              <select
                id="routes-drop-down-menu"
                // value={initialValue.Route_id}
                name="Flight_name"
                onChange={handleAddFormChange}
                defaultValue={airLineDropDownSelectedValue}
              >
                {AirLines.map((AirlineName, index) => {
                  return (
                    <option
                      key={index}
                      value={AirlineName}
                      // selected={row.Route_id}
                    >
                      {AirlineName}
                    </option>
                  );
                })}
              </select>
            </div> */}
            <div>
              <select
                id="routes-drop-down-menu"
                // value={initialValue.Route_id}
                name="Flight_Id"
                onChange={handleAddFormChange}
                defaultValue={dropDownSelectedValue}
              >
                {dropDownRoutes.map((row, index) => {
                  return (
                    <option
                      key={row.Flight_Id}
                      value={row.Flight_Id}
                      // selected={row.Route_id}
                    >
                      {row.Flight_Id} 👉 {row.Flight_name}
                    </option>
                  );
                })}
              </select>
            </div>

            <input
              className="update-form-field"
              type="date"
              name="Departure_Date"
              value={itemByID.Departure_Date}
              placeholder="Departure Date here"
              onChange={handleAddFormChange}
            />
            <input
              className="update-form-field"
              type="time"
              name="Departure_Time"
              value={itemByID.Departure_Time}
              placeholder="Departure Time Here"
              onChange={handleAddFormChange}
            />
            <input
              className="update-form-field"
              type="time"
              name="Arrival_Time"
              value={itemByID.Arrival_Time}
              placeholder="Arrival time here"
              onChange={handleAddFormChange}
            />
          </form>
          <div className="popup-btns">
            <button
              id="update-popup-update-btn"
              onClick={() => {
                flightId === 0
                  ? handleModalAddBtn()
                  : handleModelUpdateBtn(flightId);
              }}
            >
              {/* add route */}
              {flightId === 0 ? "🥳Add Schedule" : "🥳Update"}
            </button>
            <button
              id="update-popup-cancel-btn"
              onClick={() => setOpenUpdateModel(false)}
            >
              😷NO...
            </button>
          </div>
        </Modal>
        {/* Toast notification container required to show toast notification */}
        <ToastContainer theme="colored" autoClose={1500} />
      </div>
    </div>
  );
}

export default ScheduleTbl;
