import React, { useState, useEffect } from "react";
import axios from "axios";
// for date converter
import { DateFormatConverter } from "../../../utils/DateFormatConverter";
import { TableColData } from "../../../data/TableColData";
import { BounceLoader } from "react-spinners";
import { PacmanSpinner } from "../../../components/spinners/Spinner";
import "./RouteTbl.css";
import { AiFillEdit } from "react-icons/ai";
import { AiFillDelete } from "react-icons/ai";
import { BsFillCaretDownFill } from "react-icons/bs";
// icons
import { AiFillAlert } from "react-icons/ai";
import { ImPencil2 } from "react-icons/im";

import Modal from "../../popups/Modal";
// --------------------------------------------------------------------
// toast notifications
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
// --------------------------------------------------------------------

function RoutesTbl() {
  const [loading, setLoading] = useState(false); // stores spinner loading condition
  const [routes, setRoutes] = useState([]); // stores GET data from API
  const [openModel, setOpenModel] = useState(false); // store popup open boolean
  const [openUpdateModel, setOpenUpdateModel] = useState(false); // store popup open boolean
  // store routeId of table row whos EDIT | DELETE btn is clicked
  // using same form we will perform ADD-NEW-ROUTE (OR) UPDATE ROUTE
  //  routeId === 0 ? "ADD NEW ROUTE" : "UPDATE ROUTE";
  const [routeId, setRouteId] = useState(0);

  // stores new data from ADMIN
  // keep name same as Form input-name
  const initialValue = {
    Source: "",
    Destination: "",
    Distance: "",
  };
  const [itemByID, setItemByID] = useState(initialValue); // stores new Route data added by admin

  //------------ FUNCTION TO FETCH DATA FROM API ------------
  const callGetAllRoutesAPI = () => {
    axios
      .get("http://localhost:63301/api/Routes")
      .then((res) => {
        // console.log(res.data);
        setRoutes(res.data);
        setLoading(false);
      })
      .catch((err) => console.log(err));
  };

  // ------------ FUNCTION & HANDLER TO ADD NEW ROUTE  ----------
  const handleModalAddBtn = () => {
    axios
      .post(`http://localhost:63301/api/Routes`, itemByID)
      .then((res) => {
        console.log(res);
        setOpenUpdateModel(false);
        callGetAllRoutesAPI();
        toast.success("route sucessfully ADDED✨");
      })
      .catch((err) => {
        console.log(err);
        toast.error("FAILED TO ADD NEW ROUTE😭");
      });
  };

  // ------------ FUNCTION & HANDLER TO UPDATE ----------

  const updateRoute = (id) => {
    // store on id or which row we are working
    const getByIdAPI = `http://localhost:63301/api/Routes/${id}`;
    axios
      .get(getByIdAPI) //GET route_info using this id
      .then((res) => {
        setItemByID(res.data); // store recieved route info
        console.log("data by Id: " + itemByID.Destination);
        setOpenUpdateModel(true); // open modal who's form contain this stored-route_info values for editing
      })
      .catch((err) =>
        console.log(err, toast.error("FAILED TO GET DATA by Id😭"))
      );
    setRouteId(id); // hence now AddOrUpdate = update (since routeId NOT 0)
  };

  // EVENT HANDLER to store data in state: for onChange of text in <input/> call this event
  const handleAddFormChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    // make a copy of state variable containing current route-info for editing
    const newDataItem = { ...itemByID };
    newDataItem[name] = value;

    // now we have state_variable with final data that we can axios.PUT() on "update" click.
    setItemByID(newDataItem);
  };

  const handleModelUpdateBtn = (id) => {
    const apiPUT = `http://localhost:63301/api/Routes/${id}`;

    axios
      .put(apiPUT, itemByID)
      .then((res) => {
        toast.success("route sucessfully UPDATED✨");
        console.log("success:" + res);
        setOpenUpdateModel(false);
        callGetAllRoutesAPI();
      })
      .catch((err) => {
        console.log(err);
        toast.error("route failed to UPDATE😣");
      });
  };

  // ------------ function & handler to delete ------------
  const openDeleteModel = (id) => {
    setRouteId(id);
    setOpenModel(true);
  };
  const handleBtnAction = (routeId) => {
    // store API for DELETE_BY_ID
    const delAPI = `http://localhost:63301/api/routes/${routeId}`;

    axios
      .delete(delAPI)
      .then((res) => {
        callGetAllRoutesAPI();
        toast.success("sucessfully deleted😁");
      })
      .catch((err) => {
        console.log(err);
        toast.error("Route Failed to Deleted😣");
      });
    setOpenModel(false);
  };

  useEffect(() => {
    setLoading(true);
    // call fn to fetch data from API
    callGetAllRoutesAPI();
  }, [routes.length]);

  return (
    <div>
      {/* -------------- modal / pop-ups FOR DELETE WARING --------------- */}
      <Modal
        id="del-warn-popup"
        openPopup={openModel}
        closePopup={() => setOpenModel(false)}
        // pass icon CSSstyles-obj as props
        icon={<AiFillAlert size={32} />}
        iconStyles={{ backgroundColor: "#f1c40f" }}
        //  pass dialog-box CSSstyles-obj as props
        dialogBoxStyles={{
          width: "20rem",
          height: "13rem",
          borderRadius: "1rem",
          backgroundColor: "#f1f2f6",
        }}
      >
        <h1 id="popup-heading">Are you Sure🙄?</h1>
        <div className="popup-btns">
          <button
            id="alert-delete-btn"
            onClick={() => {
              console.log("clicked popup delete", handleBtnAction(routeId));
            }}
          >
            💀Delete
          </button>
          <button id="alert-cancel-btn" onClick={() => setOpenModel(false)}>
            😷NO...
          </button>
        </div>
      </Modal>
      {/* --------- spinners --------- */}
      <PacmanSpinner loading={loading} />
      <BounceLoader id="spinner-loader" loading={loading} />

      <div id="route-tbl-row1">
        <button
        id="addNew-route-btn"
          onClick={() => {
            // set routeId=0 => AddOrUpdate="add"_route
            setRouteId(0);
            // else shows initial value of this state in controlled form-field
            setItemByID({
              Source: "",
              Destination: "",
              Distance: "",
            });
            // now open form pop-up
            setOpenUpdateModel(true);
          }}
        >
          Add New Route✨
        </button>
      </div>
      <div id="route-tbl-row2">
        <table>
          {/* ------------ table columns -------------- */}
          <thead>
            <tr>
              {TableColData.routeTbl.map((item, index) => {
                return (
                  <th key={index}>
                    {item}
                    <BsFillCaretDownFill />
                  </th>
                );
              })}
            </tr>
          </thead>
          {/* -------------- table rows data from backend ------------- */}
          <tbody>
            {routes.map((route, index) => (
              // return each obj[in JSON array] mapped as JSX in format below

              <tr key={route.Route_id}>
                <td>{route.Source.toUpperCase()}</td>
                <td>{route.Destination.toUpperCase()}</td>
                <td>
                  <div
                    className={
                      route.Distance >= 1000
                        ? "rt-red badges"
                        : route.Distance >= 500
                        ? "rt-orange badges"
                        : "rt-green badges"
                    }
                  >
                    {route.Distance}
                  </div>
                </td>
                <DateFormatConverter date={route.Created_date} />
                <td>
                  {/* form EDIT btn */}
                  <button
                    id="rt-edit-btn"
                    onClick={() => updateRoute(route.Route_id)}
                  >
                    <AiFillEdit color="white" />
                  </button>

                  {/* form DELETE btn */}
                  <button
                    id="rt-delete-btn"
                    onClick={() => openDeleteModel(route.Route_id)}
                  >
                    <AiFillDelete color="#34495e" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {/* ------------- modal to update route ----------------- */}
        <Modal
          openPopup={openUpdateModel}
          closePopup={() => setOpenUpdateModel(false)}
          icon={<ImPencil2 size={32} />}
          iconStyles={{ backgroundColor: "#3dc1d3" }}
          dialogBoxStyles={{
            width: "22rem",
            height: "23rem",
            borderRadius: "1rem",
            backgroundColor: "#f1f2f6",
          }}
        > 
          {routeId === 0 ? <h1>Add New Routes🐾</h1> : <h1>Edit Routes👀</h1>}

          <form id="update-form-popup">
            <input
              className="update-form-field"
              type="text"
              name="Source"
              value={itemByID.Source}
              placeholder="Source here"
              onChange={handleAddFormChange}
            />
            <input
              className="update-form-field"
              type="text"
              name="Destination"
              value={itemByID.Destination}
              placeholder="Destination here"
              onChange={handleAddFormChange}
            />
            <input
              className="update-form-field"
              type="text"
              name="Distance"
              value={itemByID.Distance}
              placeholder="Distance here"
              onChange={handleAddFormChange}
            />
          </form>
          <div className="popup-btns">
            <button
              id="update-popup-update-btn"
              onClick={() => {
                routeId === 0
                  ? handleModalAddBtn()
                  : handleModelUpdateBtn(routeId);
              }}
            >
              {/* add route */}
              {routeId === 0 ? "🥳Add Route" : "🥳Update"}
            </button>
            <button
              id="update-popup-cancel-btn"
              onClick={() => setOpenUpdateModel(false)}
            >
              😷NO...
            </button>
          </div>
        </Modal>
        {/* Toast notification container required to show toast notification */}
        <ToastContainer theme="colored" autoClose={1500} />
      </div>
    </div>
  );
}

export default RoutesTbl;

//============== new ==================
