import React, { useState } from "react";
import "./InfoCard.css";
import { AiOutlineCloseSquare } from "react-icons/ai";
// for animation
import { motion } from "framer-motion";
import ApexCharts from "apexcharts";
import ReactApexChart from "react-apexcharts";
// TODO: in seprate file
// export const AirlineCard = (props) => {
//   return <div id="al-card"></div>;
// };

// ----------------- INFO CARD has 2 versions: compact & extended --------------------------
export const InfoCard = (props) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <>
      {/* inheritedProps: {NOT A KEYWORD}for passing props down the heirarchy we again store props in attribute and pass to child component */}
      {/* dynamically deciding to either expanded or compact based on event by user */}
      {expanded ? (
        <motion.div>
          <ExpandedInfoCard
            inheritedProps={props}
            ClickHandlerFn={() => {
              setExpanded(false);
            }}
          />
        </motion.div>
      ) : (
        <CompactInfocard
          inheritedProps={props}
          ClickHandlerFn={() => {
            setExpanded(true);
          }}
        />
      )}
    </>
  );
};

// ----------------- COMPACT CARD VERSION --------------------------
// parent fn/handler reference is passed as props to child components
const CompactInfocard = ({ inheritedProps, ClickHandlerFn }) => {
  // props-obj destructuring
  // const { title, barValue, value, icons, color } = inheritedProps;
  return (
    // MAKING COMPACT-CARD LAYOUT
    <div
      className="compact-card"
      style={{
        background: inheritedProps.color.backGround,
        boxShadow: inheritedProps.color.boxShadow,
      }}
      onClick={ClickHandlerFn} // to SET true/false "extended state"
    >
      {/* ------------ card content ---------------- */}
      {/* card column-1 */}
      <div className="card-col-1">
        <div>{inheritedProps.title}</div>
        <div>{inheritedProps.value}</div>
        <p>Till Today</p>
      </div>

      {/* card column-2 */}
      <div className="card-col-2">{inheritedProps.icon}</div>
    </div>
  );
};

// ----------------- EXTENDED CARD VERSION --------------------------
const ExpandedInfoCard = ({ inheritedProps, ClickHandlerFn }) => {
  // props-obj destructuring
  // const { title, barValue, value, icons, color } = inheritedProps;
  const data = {
    series: [
      {
        name: "series1",
        data: [31, 40, 28, 51, 42, 109, 100],
      },
      {
        name: "series2",
        data: [11, 32, 45, 32, 34, 52, 41],
      },
    ],
    options: {
      chart: {
        height: "auto",
        type: "area",
      },
      dropShadow: {
        enabled: false,
        enabledOnSeries: undefined,
        top: 0,
        left: 0,
        blur: 3,
        color: "#000",
        opacity: 0.35,
      },
      fill: {
        colors: ["#fff"],
        type: "gradient",
      },
      dataLabels: {
        enabled: false,
      },
      stroke: {
        curve: "smooth",
        colors: ["white"],
      },
      xaxis: {
        type: "datetime",
        categories: [
          "2018-09-19T00:00:00.000Z",
          "2018-09-19T01:30:00.000Z",
          "2018-09-19T02:30:00.000Z",
          "2018-09-19T03:30:00.000Z",
          "2018-09-19T04:30:00.000Z",
          "2018-09-19T05:30:00.000Z",
          "2018-09-19T06:30:00.000Z",
        ],
      },
      tooltip: {
        x: {
          format: "dd/MM/yy HH:mm",
        },
      },
      grid: {
        show: true,
      },
    },
  };
  return (
    // MAKING EXTENDED-CARD LAYOUT
    <div
      className="extd-card"
      style={{
        background: inheritedProps.color.backGround,
        boxShadow: inheritedProps.color.boxShadow,
      }}
      onClick={ClickHandlerFn}
    >
      {/* ------------ card content ---------------- */}
      {/* close btn */}
      <div id="extd-close-icon">
        <AiOutlineCloseSquare onClick={ClickHandlerFn} size={25} />
      </div>

      {/* title */}
      <div>{inheritedProps.title}</div>

      {/* chart container */}
      <div id="extd-chart-container">
        <ReactApexChart
          options={data.options}
          series={data.series}
          type="area"
        />
      </div>

      {/* footer text */}
      <p>Till Today</p>
    </div>
  );
};
