// ----------------- REACT-ICONS ------------------
import { AiOutlineUsergroupAdd } from "react-icons/ai";
import { FaRoute } from "react-icons/fa";
import { MdOutlineFlight } from "react-icons/md";
import { MdAssignment } from "react-icons/md";
import { GiReceiveMoney } from "react-icons/gi";
import { BiRupee } from "react-icons/bi";
// -----------------------------------------------
// for graph


export const InfoCardData = [
  {
    title: "Users",
    // TODO: set data num of users in all obj below
    barValue: 7, // for progress bar
    value: 14,
    icons: <AiOutlineUsergroupAdd />,
    color: {
      backGround: " #596275 ",
      boxShadow: "0px 10px 20px 0px #6a7283",
    },
    // graph data
    series: [
      {
        name: "Users",
        data: [30, 40, 35, 50, 49, 60, 70, 91, 125],
      },
    ],
  },
  {
    title: "Routes",
    barValue: 5,
    // value: 23,
    icons: <FaRoute />,
    color: {
      backGround: " #94B49F",
      boxShadow: "0px 10px 20px 0px #76907f",
    },
    // graph data
    series: [
      {
        name: "Routes",
        data: [30, 40, 35, 50, 49, 60, 70, 91, 125],
      },
    ],
  },
  {
    title: "Flights",
    barValue: 7,
    value:17,
    icons: <MdOutlineFlight  />,
    color: {
      backGround: " #f19066",
      boxShadow: "0px 10px 20px 0px #c17352",
    },
    // graph data
    series: [
      {
        name: "Flights",
        data: [30, 40, 35, 50, 49, 60, 70, 91, 125],
      },
    ],
  },
  {
    title: "Schedules",
    barValue: 7,
    value: 10,
    icons: <MdAssignment color="white"/>,
    color: {
      backGround: " #cf6a87",
      boxShadow: "0px 10px 20px 0px #a6556c",
    },
    // graph data
    series: [
      {
        name: "Schedules",
        data: [30, 40, 35, 50, 49, 60, 70, 91, 125],
      },
    ],
  },
  {
    title: "Total Revenue",
    barValue: 7,
    // value: "₹ 32,460",
    icons: <GiReceiveMoney />,
    color: {
      backGround: " #786fa6",
      boxShadow: "0px 10px 20px 0px #605985",
    },
    // graph data
    series: [
      {
        name: "Total Revenue",
        data: [30, 40, 35, 50, 49, 60, 70, 91, 125],
      },
    ],
  },
];
