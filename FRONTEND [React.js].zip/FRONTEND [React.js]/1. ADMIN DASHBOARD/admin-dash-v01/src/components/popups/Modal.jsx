import React from "react";
import { createPortal } from "react-dom";

import "./Modal.css";
import { CgClose } from "react-icons/cg";
// FOR ANIMATION
import { motion } from "framer-motion";

function Modal({
  openPopup,
  children,
  closePopup,
  icon,
  iconStyles,
  dialogBoxStyles,
}) {

  // checking "open model/popup = true or false USING TERNARY OPERATOR"

  const showPopup = openPopup ? (
    <div id="popup-container">
      <div id="popup" style={dialogBoxStyles}>
        {/* on click of CLOSE BTN assess state setter fn in parent component 
           using CLOSEPOPUP fn reference/variable */}
        <div id="pop-up-bigIcon" style={iconStyles}>
          {icon}
        </div>
        <span onClick={closePopup}>
          <CgClose size={22} />
        </span>
        {children}
      </div>
    </div>
  ) : null;
  //   INSTEAD OF JUST SIMPLY RETURNING JSX we return this JSX at another dom-node
  //   i.e here at element with id:portal-for-popup
  return createPortal(showPopup, document.getElementById("portal-for-popup"));
}

export default Modal;
