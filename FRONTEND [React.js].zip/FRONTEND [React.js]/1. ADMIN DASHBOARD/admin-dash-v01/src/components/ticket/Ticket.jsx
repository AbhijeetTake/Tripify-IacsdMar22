import React from "react";
import "./Ticket.css";
import {IoIosAirplane} from "react-icons/io"
function Ticket() {
  return (
    <div className="ticket-container">
      {/* -------- write below : COL-1---------------- */}
      <div className="barcode-sect">barcode</div>

      {/* -------- write below : COL-2 ----------------*/}
      <div className="tk-main-sect">
        {/* === main section row-1 ===*/}
        <div className="tk-main-content row-1">
          {/* passenger name */}
          <div>
            <div className="tk-mid-title">NAME OF PASSANGER</div>
            <span className="blackFont">JOHN DOE</span>
          </div>

          {/* flight name */}
          <div>
            <div className="tk-mid-title">FLIGHT</div>
            <span className="tk-value">F3954</span>
          </div>

          {/* dept date */}
          <div>
            <div className="tk-mid-title">DATE</div>
            <span className="tk-value">07 APR 2019</span>
          </div>

          {/* seat nu */}
          <div>
            <div className="tk-mid-title">SEAT</div>
            <span className="tk-value">7A</span>
          </div>
        </div>

        {/* === main section row-2 === */}
        <div className="tk-main-content row-2">
          <h1>NEW YORK</h1>
          {/* <h3>icon-here</h3> */}
          <IoIosAirplane size='50px' />
          <h1>HONG KONG</h1>
        </div>

        {/* ===  main section row-3 === */}
        <div className="tk-main-content row-3">
          <span>HAPPY JOURNEY</span>
          <span>GATE CLOSES 40 MINUTES BEFORE DEPARTURE</span>
        </div>
      </div>

      {/* -------- write below : COL-3---------------- */}
      <div className="short-info-sect">
        {/* row-1 */}
        <div id="right-row1">BARCODE</div>
        {/* row-2 */}
        <div id="right-row2">
          {/* row-2-col-1 */}
          <div id="rt-row2-col1">
            <div>
              <div className="tk-right-title">NAME OF PASSANGER</div>
              <span>JOHN DOE</span>
            </div>

            <div>
              <div className="tk-right-title">FLIGHT</div>
              <span>F3954</span>
            </div>

            <div>
              <div className="tk-right-title">DATE</div>
              <span>07 APR 2019</span>
            </div>

            <div>
              <div className="tk-right-title">SEAT</div>
              <span>7A</span>
            </div>
          </div>
          {/* row-2-col-2 */}
          <div className="rt-row2-col2">
            <span >NEW YORK</span>
            <IoIosAirplane size='20px' style = {{transform: 'rotate(90deg)' }}/>
            <span>HONG KONG</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Ticket;
