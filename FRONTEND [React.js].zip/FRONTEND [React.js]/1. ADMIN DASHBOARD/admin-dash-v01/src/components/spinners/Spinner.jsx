import React, { useState } from "react";
import "./Spinner.css";
import PacmanLoader from "react-spinners/PacmanLoader";
import HashLoader from "react-spinners/HashLoader";
import ScaleLoader from "react-spinners/ScaleLoader";

export const PacmanSpinner = function Spinner({ loading }) {
  return (
    <>
      {
        // if fetching/DataLoading work is still going on show spinners else show data
        loading ? (
          <div id="spinner-page">
            {
              <div id="spinner-container">
                {
                  <div id="spinner">
                    <ScaleLoader color=" #b49fda " loading={loading} />
                  </div>
                }
              </div>
            }
          </div>
        ) : null
      }
    </>
  );
};
