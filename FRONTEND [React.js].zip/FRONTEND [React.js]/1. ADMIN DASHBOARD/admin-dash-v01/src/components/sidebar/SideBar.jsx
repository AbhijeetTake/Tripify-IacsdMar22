import React, { useState } from "react";
import "./SideBar.css";
import icon from "../../assets/images/icon.png";
import { SideBarData } from "./SideBarData"; // data for side-Bar options
import { Link } from "react-router-dom";
function SideBar({ children }) {
  // state to keep track of: SIDEBAR OPTION ACTIVE of which index of SideBar Data array?
  // state store index value of clicked sidebar div / option
  const [selected, setSelected] = useState(0);

  return (
    <>
      <div className="sidebar-container">
        {/* LOGO */}
        <div className="title-container">
          <img src={icon} alt="icon" srcSet="" />
          <span>Dashboard</span>
        </div>

        {/* MENU OPTIONS : load all sidebar option in react way*/}
        <div id="menu-container">
          {SideBarData.map((obj, index) => {
            return (
              // className decides if option is active/selected or not
              <Link
                to={obj.routePath}
                className={
                  selected === index ? "menu-item active" : "menu-item"
                }
                key={index}
                onClick={() => setSelected(index)}
              >
                {obj.icon}
                <span>{obj.title}</span>
              </Link>
            );
          })}
          <Link
          id="logout-btn"
            to="/login"
            // className={
            //   selected === index ? "menu-item active" : "menu-item"
            // }
            onClick={() => localStorage.removeItem("token")}
            style={{
              textDecoration: "none",
              fontSize: "0.8rem",
              fontWeight:"bold",
              marginLeft: "3.5rem",
              marginRight:"3.5rem",
              border: "2px solid black",
              paddingLeft:"1rem",
              paddingRight:"1rem",
            }}
          >
            {/* icon */}
            <span >LOGOUT</span>
          </Link>
        </div>
      </div>
      {/* -----------------------info: MAIN CONTENT SECTION --------------------------- */}
      <main id="content-container">{children}</main>
    </>
  );
}

export default SideBar;
