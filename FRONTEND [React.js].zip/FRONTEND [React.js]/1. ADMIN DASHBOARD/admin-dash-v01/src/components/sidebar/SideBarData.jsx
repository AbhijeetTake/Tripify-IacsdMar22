//----------- icons from React-library: REACT-ICON ------------------
import { BiHomeAlt } from "react-icons/bi";
import { HiUserGroup } from "react-icons/hi";
import { FaRoute } from "react-icons/fa";
import { AiOutlineSchedule } from "react-icons/ai";
import { MdOutlineFlightTakeoff } from "react-icons/md";
// ----------------------------------------------------------------------

// array of  sidebar data of all option
export const SideBarData = [
  {
    icon: <BiHomeAlt />,
    title: "Home",
    routePath: "/",
  },
  {
    icon: <HiUserGroup />,
    title: "Users",
    routePath: "/users",
  },
  {
    icon: <FaRoute />,
    title: "Routes",
    routePath: "/routes",
  },
  {
    icon: <MdOutlineFlightTakeoff />,
    title: "Flights",
    routePath: "/flights",
  },
  {
    icon: <AiOutlineSchedule />,
    title: "Schedules",
    routePath: "/schedules",
  },
];
