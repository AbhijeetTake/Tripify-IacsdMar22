// names of table coloumns to show in tbl
export const TableColData = {
  routeTbl: ["Source", "Destination", "Distance", "Created on", "Actions"],
  flightTbl: [
    "FlightID",
    "RouteID",
    "AirLine",
    "BussCap",
    "EcoCap",
    "BussFee",
    "EcoFee",
    "Created on",
    "Actions",
  ],
  scheduleTbl: [
    "SchedID",
    "FlightID",
    "Src",
    "Dest",
    "Depart Date",
    "Depart Time",
    "Arrival Time",
    "Actions",
  ],
  userTbl: [
    "UserID",
    "Full_Name",
    "Email",
    "Phone_Nu",
    "Address",
    "Actions",
  ],
};
