import React from "react";

export const DateFormatConverter = ({ date }) => {
  // CONVERT DATE TO PROPER FORMAT

  //   #step-1: split at either of these delimiters
  const dateArr = date.split(/[-,T,:]/);

  // #step-2: represent in required format: Eg:[DD/MM/YYYY]
  const convertedDate = `${dateArr[2]}/${dateArr[1]}/${dateArr[0]}`; // dd/mm/yyyy

  return <td>{convertedDate}</td>;
};
