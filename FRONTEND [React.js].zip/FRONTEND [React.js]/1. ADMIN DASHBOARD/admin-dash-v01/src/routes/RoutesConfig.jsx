import React from "react";
import { Routes, Route } from "react-router-dom";
// ----------------------- IMPORTING PAGES -----------------------------
import { ProtectedPages } from "../pages/ProtectedPages";
import { HomePage } from "../pages/home/HomePage";
import { UsersPage } from "../pages/user/UsersPage";
import { RoutesPage } from "../pages/route/RoutesPage";
import { SchedulesPage } from "../pages/schedule/SchedulesPage";
import { FlightsPage } from "../pages/flight/FlightsPage";
import { LoginPage } from "../pages/login/LoginPage";
import { NoMatchPage } from "../pages/page404/NoMatchPage";
// ---------------------------------------------------------------------
export const RoutesConfig = () => {
  return (
    <>
      <Routes>
        {/* dont pass directly element when respective url is used INSTEAD PASS IT THROUGH A PAGE TO VALIDATE */}
        <Route path="/" element={<ProtectedPages ValidatePage={HomePage} />} />
        {/*HOME PAGE*/}
        <Route
          path="/users"
          element={<ProtectedPages ValidatePage={UsersPage} />}
        />
        <Route
          path="/routes"
          element={<ProtectedPages ValidatePage={RoutesPage} />}
        />
        <Route
          path="/flights"
          element={<ProtectedPages ValidatePage={FlightsPage} />}
        />
        <Route
          path="/schedules"
          element={<ProtectedPages ValidatePage={SchedulesPage} />}
        />
        <Route path="/login" element={<LoginPage />} />
        <Route path="*" element={<NoMatchPage />} />
      </Routes>
    </>
  );
};
