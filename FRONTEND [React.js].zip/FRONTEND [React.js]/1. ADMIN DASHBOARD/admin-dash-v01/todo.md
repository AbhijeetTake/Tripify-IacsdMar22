[x] dynamic modal using portal
[ ] dynamic tables

----------------------------------------
# Requests.jsx
const id=0;

const requests = {
    fetchRoutes: `/Routes()`,
    fetchSchedules: `/Schedules`,
    fetchFlights: `/Flights`,
    updateRoutes: `/Routes/${id}`,
    updateSchedules: `/Schedules/${id}`,
    updateFlights: `/Flights/${id}`,
    
}
------------------------------------------
# for TICKET
- use "scale" property to increase or decrease size

