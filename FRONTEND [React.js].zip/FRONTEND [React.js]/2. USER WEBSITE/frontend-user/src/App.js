// import logo from './logo.svg';
// import Footer_2 from './components/Footer_2';
// import SocialMedia from './components/SocialMedia';
// import Router_Popup from './components/Router_Popup';
// import Temp from './components/Temp';
// import Router_UpdatePop from './components/Router_UpdatePop';
// import Admin_Router_Function from './components/Admin_Router_Function';
// import Footer from './components/Footer_new';
// import Header_temp from './components/Header_temp';
// import Schedules_List from './components/Schedules_List';
// import EmailService from './components/Invoice/EmailService';
// import DynamicForm from './components/BookingPage/DynamicForm';
import Register_Page from './components/Register_Page';
import Invoice_Invoker from './components/Invoice/Invoice_Invoker'
import SeatPage from './components/BookingPage/SeatPage';
import {Routes,Route} from 'react-router-dom'
import './App.css';
import Login_Page from './components/Login_Page';
import React from 'react';
import Search_schedule_bar from './components/Search_schedule_bar';
import Header_v1 from './components/Header_v1';
import Footer_v2 from './components/Footer_v2';
import { ProtectedPages } from './components/validation/ProtectedPages';
import { NoMatchPage }  from '../src/components/page404/NoMatchPage.jsx'
import { Payment } from './components/payment/Payment';
import {LandingPage} from  './components/LandingPage/LandingPage/LandingPage'
import Ticket from './components/ticket/ticket/Ticket';

function App() {

  return (
    <div>
    
    <Header_v1/>

     {/* <Register_Page/>  */}
     {/* <Ticket/> */}

    {/* <Admin_Router_Function/> */}

    {/* <SeatPage/> */}
    {/* <DynamicForm/> */}

    {/* Route Implementation */}


    <Routes>
    <Route path='/login' element={<Login_Page/>} />
    <Route path='/schedules' element={<ProtectedPages ValidatePage={Search_schedule_bar} />}/>
    <Route path='/bookingpage' element={<ProtectedPages ValidatePage={SeatPage} />}/>
    <Route path='/payment' element={<ProtectedPages ValidatePage={Payment} />}/>
    <Route path='/invoice' element={<ProtectedPages ValidatePage={Invoice_Invoker} />}/>
    <Route path='/register' element={<Register_Page/>}/>
    <Route path='/' element={<LandingPage/>}/>
    <Route path='*' element={<NoMatchPage/>} />
    </Routes>

    {/* <Link to='/' >anchor tag text</Link>  */}

    {/* <Invoice_Invoker/>  */}
    {/* <EmailService/> */}

    <Footer_v2/>

    </div>
  );
}

export default App;