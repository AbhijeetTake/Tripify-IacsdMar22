import styled from "styled-components";


export const Social = styled.social`

  background-color: rgb(98 84 243);
  color: rgb(255 255 255);
  padding: 1.4rem 2.4rem;
  
`;