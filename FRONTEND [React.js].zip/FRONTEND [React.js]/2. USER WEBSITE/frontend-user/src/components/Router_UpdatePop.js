import axios from "axios";
import React,{useState} from "react";
import "../styles/Router-Modal.css";
import Admin_Router_Function from "./Admin_Router_Function";

function Router_UpdatePop({item,closeModal,items}) {

    const [updatedItem , setUpdatedItem] = useState({
        Route_id : item.Route_id,
        Source : item.Source,
        Destination : item.Destination,
        Distance : item.Distance,
        Created_date : ''
    }) 

    const styleObj = {
        width: "600px",    
        height: "600px",
    }

    const getCurrentDateTime = () => {

        var date = new Date().getDate(); //Current Date
        var month = new Date().getMonth() + 1; //Current Month
        var year = new Date().getFullYear(); //Current Year
        var hours = new Date().getHours(); //Current Hours
        var min = new Date().getMinutes(); //Current Minutes
        var sec = new Date().getSeconds(); //Current Seconds

        const timeStamp = year + '-' + month + '-' + date + 'T' + hours + ':' + min + ':' + sec
        return timeStamp

    }

    const handleInputChangeEvent = (e) => {
        console.log('e => ' , e);
        const newDataItem =  {...updatedItem}
        newDataItem[e.target.name] = e.target.value
        newDataItem.Created_date = getCurrentDateTime()
        setUpdatedItem(newDataItem)
        console.log(newDataItem);
    }

    const handlePutRequest = (e) => {
        console.log( 'updatedItem ===> ' , updatedItem);
        const url = `http://localhost:63301/api/routes/${updatedItem.Route_id}` 
        axios.put(url , updatedItem )
        .then(
            alert("SuccessFully Updated!!" , closeModal(false) , items([]))
        ).catch(
            (err) => {console.log(err , "UnSuccessFull Update!!", closeModal(false)) } 
        )
    }


  return (
    <div className="modalBackground">
      <div className="modalContainer" style={styleObj}>
      <div className="titleCloseBtn">
          <button
            onClick={() => {
              closeModal(false);
            }}
          >
            x
          </button>
        </div>
        <h2>Update Route Item</h2>
        <div className="body">
            
        <form onSubmit={(e)=> handlePutRequest(e)}>
            <div className="form-group">
                <label>RouteID</label>
                <input type="text" name="Route_id" onChange={(e)=> handleInputChangeEvent(e)} className="form-control" defaultValue={item.Route_id} disabled/>
                {/* <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> */}
            </div>
            <div className="form-group">
                <label>Source</label>
                <input type="text" name="Source" onChange={(e)=> handleInputChangeEvent(e)} className="form-control" defaultValue={item.Source} />
                {/* <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> */}
            </div>
            <div className="form-group">
                <label>Destination</label>
                <input type="text" name="Destination" onChange={(e)=> handleInputChangeEvent(e)} className="form-control" defaultValue={item.Destination} />
                {/* <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> */}
            </div>
            <div className="form-group">
                <label>Distance</label>
                <input type="text" name="Distance" onChange={(e)=> handleInputChangeEvent(e)} className="form-control" defaultValue={item.Distance} />
                {/* <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> */}
            </div>

            <button type="submit" className="btn btn-primary  btn-sm">Update Route </button>
            <button type="cancel" className="btn btn-danger  btn-sm" onClick={() => closeModal(false)}> Cancel</button>
        </form>
        </div>

      </div>
    </div>

  );

}

export default Router_UpdatePop;
