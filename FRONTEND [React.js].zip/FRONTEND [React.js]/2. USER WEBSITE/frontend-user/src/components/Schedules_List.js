import React,{useEffect, useState} from 'react'
import { useNavigate } from 'react-router-dom'
import '../styles/router.css'
import axios from 'axios'
import '../App.css';
// import { DateFormatConverter } from "../utils/DateFormatConverter";

function Schedules_List({filteredParams , SeatCount , SeatType}) {

    const [scheduleList , setScheduleList] = useState([])
    const [filteredList , setFilteredList] = useState([])
    const Navigate = useNavigate()

    useEffect(() => {
        callGetAllSchedulesAPI()

        // console.log('Inside Schedule List');
        // console.log('FilteredParams => ' , filteredParams);
        // console.log('SeatCount => ' , SeatCount);
        // console.log('SeatType => ' , SeatType);

    },[scheduleList.length])



    const callGetAllSchedulesAPI = () => {
        const url = 'http://localhost:63301/api/Schedules/'
        axios.get(url)
        .then(
            (response) =>{
                setScheduleList(response.data)
                // console.log( 'scheduleList' , scheduleList);
                getFilteredSchedules(filteredParams)
            } 
        ).catch(
            (err) => { console.log( 'Failed to Retrieve Records' , err.response);} 
        )
    }

    const handleBookTicket = (Schedule_Item) => {
        const Booking_Item = {
        SeatsCount : SeatCount,
        ClassType : SeatType, 
        scheduleItem : {...Schedule_Item}
    }
    console.log('Booking-ITEM => ',Booking_Item)
    sessionStorage.setItem("selectedScheduleInfo",JSON.stringify(Booking_Item))
    setTimeout(() => Navigate('/bookingpage'),500)
}

    const getFilteredSchedules = (ScheduleObject) => {

        if(scheduleList.length > 0){
            let filteredItems = scheduleList.filter(
                item => item.Source === ScheduleObject.Source && item.Destination === ScheduleObject.Destination 
                && (item.DepartureDate.split(/[T]/)[0].toString()) == (ScheduleObject.DepartureDate)
                // && parseInt(item.DepartureDate.split(/[T]/)[0].split(/[-]/)[0].toString()) == parseInt(ScheduleObject.DepartureDate.split(/[-]/)[0].toString())

            ).map((item,index) => {
                return (
                    <tr key={index+1}>
                    <td>{index+1}</td>
                    <td>{item.FlightName}</td>
                    <td> {item.DepartureDate.split(/[T]/)[0].toString()} & {item.DepartureTime.split(/[T]/)[1]}</td>
                    <td>{item.Source}</td>
                    <td>{item.Destination}</td>
                    <td>{item.Distance}Km</td>
                    <td>{item.ArrivalTime.split(/[T]/)[1]}</td>
                    <td>{item.EconomyFee} Rs</td>
                    <td>{item.BusinessFee} Rs</td>
                    <td><button onClick={() => handleBookTicket(item)} className='btn btn-primary'>Book</button></td>
                    </tr>
                )
            })
            // console.log('filteredItems' , filteredItems);
            setFilteredList(filteredItems)
            // console.log('filteredList' , filteredList);
        }

    }

  return (
    <div className='container router-root'>
    <div className='router-div'>
    <h2>Schedule Page</h2>
    <div className='new-routes-bar'>
        <p>All Schedules</p>
    </div>
    <div className='search-bar-router'>
        {/* <div >            
            <label>Show </label>
            <select className="custom-select mr-sm-2" id="inlineFormCustomSelect" defaultValue={10}>
            <option value="10">10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            </select>
            <label> entries</label>
        </div> */}
    </div>

    <br/>
    <table className='table table-bordered'>
        <thead className='table-list-header'>
            <tr>
                <th>ID</th>
                <th>FlightName</th>
                <th>DepartureDate&Time</th>
                <th>Source</th>
                <th>Destination</th>
                <th>Distance</th>
                <th>ArrivalTime</th>
                <th>Economy(/seat)</th>
                <th>Business(/seat)</th>
                <th></th>
            </tr>
        </thead>

        <tbody>
            {filteredList}
        </tbody>
    </table>
    </div>
  </div>

  )
}

export default Schedules_List