import React from 'react'
import '../styles/footer2css.css'
import SocialMedia from './SocialMedia'


function Footer_2() {
  return (

<footer class="section-footer">
    <hr/>
    <br/><br/>
<div class="container grid grid-three-column">
<div class="f-about">
    <h3><u>Stay Connected</u></h3>
    <p>Subscribe to get Email-Exclusive Coupouns.</p>
    <input type="text" placeholder='Your Email Here' className='input-footer'/>
    <button className='input-btn' >Get Coupouns</button>
    <br/>
    <div className='input-chkbox-text' >
    <input type="checkbox" /><label>By checking this box , I agree to get Updates </label>
    </div>
    <div>
          <br/><br/><br/>
          <SocialMedia/>
    </div>

    
  </div>



  <div class="f-links">
    <h3><u>Company</u></h3>
    <ul>
      <li>
        <span><ion-icon name="arrow-forward-outline"></ion-icon></span
        ><a href="#">About Us</a>
      </li>
      <li>
        <span><ion-icon name="arrow-forward-outline"></ion-icon></span
        ><a href="#">FAQ'S</a>
      </li>
      <li>
        <span><ion-icon name="arrow-forward-outline"></ion-icon></span
        ><a href="#">Terms&Conditions</a>
      </li>
      <li>
        <span><ion-icon name="arrow-forward-outline"></ion-icon></span
        ><a href="#">Home</a>
      </li>
    </ul>
  </div>



  <div class="f-address">
    <h3><u>Explore</u></h3>
    <address>
      <div>
        <p>
          <span><ion-icon name="location-outline"></ion-icon></span>
          Home
        </p>
      </div>

      <div>
        <p>
          <span><ion-icon name="call-outline"></ion-icon></span>
          <a href="tel:+919876543211"> EasyFlight </a>
        </p>
      </div>

      <div>
        <p>
          <span><ion-icon name="mail-outline"></ion-icon></span>
          <a href="#">
            Hotel
          </a>
        </p>
      </div>

      <div>
        <p>
          <span><ion-icon name="call-outline"></ion-icon></span>
          <a href="#"> Bundle </a>
        </p>
      </div>

    </address>
  </div>
</div>

<div class="container">
  <div class="f-social-icons">
    <a href="https://www.instagram.com/thapatechnical/" target="_blank">
      <ion-icon class="icons" name="logo-instagram"></ion-icon>
    </a>

    <a href="https://discord.gg/MdScmCsua6" target="_blank">
      <ion-icon class="icons" name="logo-discord"></ion-icon>
    </a>

    <a href="https://www.youtube.com/thapatechnical" target="_blank">
      <ion-icon class="icons" name="logo-youtube"></ion-icon>
    </a>
  </div>

  <div class="f-credits">
    <hr/>
    <br/><br/>
    <p>
      Copyright ©2022 All rights reserved | *Tripify LLC*
    </p>
  </div>
</div>
</footer>
  )
}

export default Footer_2