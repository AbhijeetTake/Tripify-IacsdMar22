// import Router_Popup from './components/Router_Popup';
import Admin_router from './Admin_router';
import React ,{useState}from 'react';

function PopHandler() {

  const [ openRouterModal , setOpenRouterModal ] = useState(true);

  return (
    <React.Fragment>
    {/* {  openRouterModal && <Router_Popup closeModal={setOpenRouterModal}/>}
    { !openRouterModal && <Admin_router/>} */}

    <h1>Inside PopHandler</h1>
    </React.Fragment>
  );
}

export default PopHandler;