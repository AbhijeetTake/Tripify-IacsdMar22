import React, { useEffect, useState } from "react";
import Schedules_List from "../components/Schedules_List";
import "../styles/Search_bar.css";
import axios from "axios";


function Search_schedule_bar() {
  const [valueSrc, setValueSrc] = useState("");
  const [valueDest, setValueDest] = useState("");
  const [routes, setRoutes] = useState([]);
  const [seatCount , setSeatCount ] = useState(1)
  const [uniqueRoutesSrc, setUniqueRoutesSrc] = useState([]);
  const [uniqueRoutesDest, setUniqueRoutesDest] = useState([]);
  const [classType , setClassType] = useState('')
  const [filteredParameters, setFilteredParameters] = useState({
    Flight_ID: 1,
    Schedule_ID: 2,
    Route_ID: 1,
    Source: "New Delhi (DEL)",
    Destination: "Indore (IDR)",
    FlightName: "Virgin",
    Distance: 1235,
    BusinessFee: 8555.55,
    EconomyFee: 4888.67,
    DepartureDate: "2022-02-02T00:00:00",
    DepartureTime: "15:08:50.0740156",
    ArrivalTime: "15:08:50.0740156"
  });

  const callGetAllRoutesAPI = () => {
    //fetch data from API
    axios
      .get("http://localhost:63301/api/Routes")
      .then((response) => {
        // console.log('All Routes',response.data);
        setRoutes(response.data);
      })
      .catch((err) => console.error(err));
  };

  const handleOnlyRouteSource = () => {
    const mySet = new Set();
    routes.map((item) => {
      return (
        mySet.add(item.Source)
      )
    });
    const uniqueRoutes = Array.from(mySet);
    setUniqueRoutesSrc(uniqueRoutes);
    setValueSrc(filteredParameters.Source);
  };

  const handleOnlyRouteDestination = () => {
    const mySet = new Set();
    routes.map((item) => {
      return (
        mySet.add(item.Destination)
      )
    });
    const uniqueRoutes = Array.from(mySet);
    setUniqueRoutesDest(uniqueRoutes);
    setValueDest(filteredParameters.Destination);
  };

  const handleInputChangeEvent = (e) => {
    const newDataItem = { ...filteredParameters }
    newDataItem[e.target.name] = e.target.value
    setFilteredParameters(newDataItem)
    // console.log('classType => ',classType);
    // console.log('filteredParameters => ',filteredParameters);

    e.target.name == "Source" ? setValueSrc(e.target.value) 
    :e.target.name == "Destination" ? setValueDest(e.target.value)
    :console.log()

    // console.log('filteredParameters => ' , filteredParameters);
    // e.target.name == "Source" || "Destination"
    //   ? handleOnTimeSearch(e.target.name, e.target.value)
    //   : console.log("current triggered input : ", e.target.name);
  };

  const handleSearchRequest = (e) => {
    sessionStorage.setItem(
      "prevFilteredState",
      JSON.stringify(filteredParameters)
    );
    // e.preventDefault();
  };

  // const handleOnTimeSearch = (targetName, searchItem) => {
  //     //extra specific functionalities/validations
  //     //can be added later
  // }

  const getSrcDropdown = () => {
    const dropDownSrcList = uniqueRoutesSrc
      .filter((item) => {
        const searchTerm = valueSrc.toLowerCase();
        const fullName = item.toLowerCase();

        return (
          searchTerm &&
          fullName.startsWith(searchTerm) &&
          fullName != searchTerm
        );
      })
      .slice(0, 5)
      .map((item) => {
        return (
          <div
            onClick={() => onSearch("Source",item)}
            className="dropdown-row"
            key={item}
          >
            {item}
          </div>
        )
      })

      return dropDownSrcList == undefined ? null : dropDownSrcList
  };

  const getDestDropdown = () => {
    const dropDownDestList = uniqueRoutesDest
      .filter((item) => {
        const searchTerm = valueDest.toLowerCase();
        const fullName = item.toLowerCase();

        return (
          searchTerm &&
          fullName.startsWith(searchTerm) &&
          fullName != searchTerm
        );
      })
      .slice(0, 5)
      .map((item) => {
        return (
          <div
            onClick={() => onSearch("Destination",item)}
            className="dropdown-row"
            key={item}
          >
            {item}
          </div>
        )
      })

      return dropDownDestList == undefined ? null : dropDownDestList
  };

  const onSearch = ( target , value) => {
    const newDataItem = {...filteredParameters}
    target == "Source" ? newDataItem.Source = value : newDataItem.Destination = value
    setFilteredParameters(newDataItem)
    target == "Source" ? setValueSrc(newDataItem.Source) : setValueDest(newDataItem.Destination)
  };

  const handleMinus = () => {
    if(seatCount > 1){
      sessionStorage.setItem('seatCount',seatCount-1)
      setSeatCount(seatCount-1)
    }
  }

  const handlePlus = () => {
    if(seatCount < 3){
      sessionStorage.setItem('seatCount',parseInt(seatCount) + 1)
      setSeatCount(parseInt(seatCount)+1)
    }
  }

  const handleClassType = (e) => {
    setClassType(e.target.value);
    sessionStorage.setItem('seatType',e.target.value)
    // console.log('Input Change - ClassType => ' , classType);
  }

  useEffect(() => {
    callGetAllRoutesAPI();
    handleOnlyRouteSource();
    handleOnlyRouteDestination();

    // console.log('filteredParameters => ',filteredParameters);
    // console.log('SeatType => ', classType);

  }, [routes.length, uniqueRoutesSrc.length, uniqueRoutesDest.length]);

  useEffect(() => {
    const getFilteredLocalParams = JSON.parse(sessionStorage.getItem("prevFilteredState")) // {}
    getFilteredLocalParams != undefined || null ? setFilteredParameters(getFilteredLocalParams)
    : console.log(`Couldn't able to retrieve FilteredParams from Session Storage`);

    const getSeats = sessionStorage.getItem('seatCount')
    getSeats != undefined || null ? setSeatCount(getSeats)
    : console.log(`Couldn't able to retrieve SeatsCount from Session Storage`);

    const getSeatType = sessionStorage.getItem('seatType')
    getSeatType != undefined || null ? setClassType(getSeatType)
    : console.log(`Couldn't able to retrieve getSeatType from Session Storage`);

    // const getDepartDate = sessionStorage.getItem('departDate')
    // getSeats != undefined || null ? setSeatCount(getSeats)
    // : console.log(`Couldn't able to retrieve SeatsCount from Session Storage`);
     
    console.log('token inside search bar ln: 204 => ' , localStorage.getItem("token"));
  }, []);

  return (
    <div>
      <div className="search-body">
        <div>
          <form onSubmit={(e) => handleSearchRequest(e)}>
            <div className="grid-container">
              <div className="grid-item">
                <table>
                  <thead>
                    <tr>
                      <th>From</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <input
                          type="text"
                          name="Source"
                          value={valueSrc}
                          onChange={(e) => handleInputChangeEvent(e)}
                          required
                        />
                        <div className="dropdown">{getSrcDropdown()}</div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="grid-item">
                <table>
                  <thead>
                    <tr>
                      <th>To</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <input
                          type="text"
                          name="Destination"
                          value={valueDest}
                          onChange={(e) => handleInputChangeEvent(e)}
                          required
                        />
                        <div className="dropdown">{getDestDropdown()}</div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="grid-item">
                <table>
                  <thead>
                    <tr>
                      <th>Departure Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <input
                          type="date"
                          name="DepartureDate"
                          onChange={(e) => handleInputChangeEvent(e)}
                          value={filteredParameters.DepartureDate}
                          required
                        />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="grid-item">
                <table>
                  <thead>
                    <tr>
                      <th>Seats</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <div className="seats-counter-head">
                          <span><button onClick={handleMinus}> - </button></span>
                          {seatCount}
                          <span><button onClick={handlePlus}> + </button></span>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="grid-item">
                <table>
                  <thead>
                    <tr>
                      <th>Passenger&Class</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <select  value={classType} onChange={(e) => {handleClassType(e)}}>
                          <option className="seat-select-option" value="Economy" name="ClassType" >Economy</option>
                          <option className="seat-select-option" value="Business" name="ClassType" >Business</option>
                        </select>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="grid-item item6">
                <table>
                  <tbody>
                    <tr>
                      <td>
                        <button className="btn btn-primary">
                          Update Search
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </form>
        </div>
      </div>
      <Schedules_List filteredParams={filteredParameters} SeatCount={seatCount} SeatType={classType} />
    </div>
  );
}

export default Search_schedule_bar;
