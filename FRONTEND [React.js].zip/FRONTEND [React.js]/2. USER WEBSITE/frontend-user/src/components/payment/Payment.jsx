import React, { useEffect, useState } from "react";
import "./Payment.css";
import chip from "./chip.png";
import visa from "./visa.png";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { v4 } from "uuid";

export const Payment = () => {
  const Navigate = useNavigate();
  const [number, setNumber] = useState("12345xxxxxxxxx91");
  const [name, setName] = useState("");
  const [expiryMM, setExpiryMM] = useState("mm");
  const [expiryYY, setExpiryYY] = useState("yyyy");
  const [cvv, setCvv] = useState("");
  const [FinalBooking, setFinalBooking] = useState({});
  const [scheduleDetails, setScheduleDetails] = useState({});

  const currFee = parseInt(JSON.parse(sessionStorage.getItem("Final_Booking")).seats) * (JSON.parse(sessionStorage.getItem("Final_Booking")).seat_type == "Economy" ? parseFloat(JSON.parse(sessionStorage.getItem("selectedScheduleInfo")).scheduleItem.EconomyFee) : parseFloat(JSON.parse(sessionStorage.getItem("selectedScheduleInfo")).scheduleItem.BusinessFee));

  const pricePerSeat =  (JSON.parse(sessionStorage.getItem("Final_Booking")).seat_type == "Economy"
    ? parseFloat(JSON.parse(sessionStorage.getItem("selectedScheduleInfo")).scheduleItem.EconomyFee)
    : parseFloat(JSON.parse(sessionStorage.getItem("selectedScheduleInfo")).scheduleItem.BusinessFee));

  const currTax = currFee * 0.2;

  sessionStorage.setItem("currentFee",currFee)
  sessionStorage.setItem("pricePerSeat",pricePerSeat)
  sessionStorage.setItem("currentTax",currTax)


// console.log("token inside Payment ln:34 :userID | fee ", userID, fee);

  useEffect(() => {
    const Final_Booking = JSON.parse(sessionStorage.getItem("Final_Booking"));
    Final_Booking != undefined || null
      ? setFinalBooking(Final_Booking)
      : console.log(
          "Couldn't able to retrieve FinalBooking from Session Storage"
        );

    const CurrentScheduleDetails = JSON.parse(
      sessionStorage.getItem("selectedScheduleInfo")
    );
    CurrentScheduleDetails != undefined || null
      ? setScheduleDetails(CurrentScheduleDetails)
      : console.log(
          "Couldn't able to retrieve CurrentScheduleDetails from Session Storage"
        );

    console.log("Final Booking Before Final POST => ", FinalBooking);
    console.log("Final scheduleDetails Before Final POST => ", scheduleDetails);

    console.log("Final Booking Before Final POST => ", Final_Booking);
    console.log(
      "Final scheduleDetails Before Final POST => ",
      CurrentScheduleDetails
    );
  }, []);

  const handleBookSeats = (e) => {
    alert("Your Booking a Ticket !");
    console.log(
      "Before Final POST => ",
      JSON.parse(sessionStorage.getItem("Final_Booking"))
    );

    axios
      .post("http://localhost:63301/api/Booking/", FinalBooking)
      .then((Response) => {
        alert("Your Ticket is Successfully Booked !");
        const BookingID = parseInt(Response.data);
        const userID = parseInt(localStorage.getItem("token"));

        const fee =
          parseInt(FinalBooking.seats) *
          (FinalBooking.seat_type == "Economy"
            ? parseFloat(scheduleDetails.scheduleItem.EconomyFee)
            : parseFloat(scheduleDetails.scheduleItem.BusinessFee));
        console.log("token inside Payment ln:34 :userID | fee ", userID, fee);

        console.log("scheduleDetails => ", scheduleDetails);
        console.log(
          "parseInt(FinalBooking.seats)",
          parseInt(FinalBooking.seats)
        );
        console.log("FinalBooking.seat_type", FinalBooking.seat_type);
        console.log(
          "parseFloat(scheduleDetails.EconomyFee)",
          scheduleDetails.EconomyFee
        );
        console.log(
          "parseFloat(scheduleDetails.BusinessFee)",
          scheduleDetails.BusinessFee
        );
        console.log("parseFloat(fee)", parseFloat(fee));

        const PaymentObject = {
          booking_id: BookingID,
          user_id: userID,
          transaction_id: v4(),
          schedule_id: FinalBooking.schedule_id,
          amount: parseFloat(fee),
          tax_amount: parseFloat(parseFloat(fee) * 0.2),
        };
        console.log("transaction_id => ", PaymentObject.transaction_id);
        axios
          .post("http://localhost:63301/api/Payments/", PaymentObject)
          .then((Res) => {
            alert("Your Payment is Successfully Added !");
            // sessionStorage.clear();
            setTimeout(() => {
              Navigate("/invoice");
            }, 500);
          })
          .catch((err) => {
            console.log(err);
            alert("Un-Successfull of Payment");
          });
      })
      .catch((err) => {
        alert("Un-Successfull of Booking");
        console.log(err);
      });
    e.preventDefault();
  };

  return (
    <>


      <div id="user-payment-pg-payment">

        <div className="container-payment">

          
      <div id="fee-div">
        <h3>Amount = {FinalBooking.seats} * {pricePerSeat} = {currFee} RS</h3>
        <h3>Tax = {currFee} * 20% = {currTax} RS </h3>
        <h3>Final Amount = {currFee} + {currTax} = {currFee+currTax} RS</h3>
      </div>

          <div className="card-container-payment">
            <div className="front-payment">
              <div className="image-payment">
                <img
                  src={chip}
                  alt="chipPic"
                  style={{ width: "3rem", height: "3rem" }}
                />
                <img src={visa} alt="visaPic" style={{ width: "3.5rem" }} />
              </div>
              <div className="card-number-box-payment">{number}</div>
              <div className="flexbox-payment">
                <div className="box-payment">
                  <span>card holder</span>
                  <div className="card-holder-name-payment">{name}</div>
                </div>
                <div className="box-payment">
                  <span>expires</span>
                  <div className="expiration-payment">
                    <span className="exp-month-payment">{expiryMM}</span>
                    <span>/</span>
                    <span className="exp-year-payment">{expiryYY}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="back-payment">
              <div className="stripe-payment"></div>
              <div className="box-payment">
                <span>{cvv}</span>
                <div className="cvv-box-payment"></div>
                <img
                  src="image/visa.png"
                  alt="visa-logo"
                  style={{ width: "2rem" }}
                />
              </div>
            </div>
          </div>

          <form action="">
            <div className="inputBox-payment">
              <span>card number</span>
              <input
                placeholder="number"
                type="text"
                maxLength="16"
                className="card-number-input-payment"
                onChange={(e) => setNumber(e.target.value)}
                required
              />
            </div>
            <div className="inputBox-payment">
              <span>card holder</span>
              <input
                placeholder="full name"
                type="text"
                className="card-holder-input-payment"
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div className="flexbox-payment">
              <div className="inputBox-payment">
                <span>expiration mm</span>
                <select
                  defaultValue="month"
                  name=""
                  id=""
                  className="month-input-payment"
                  onChange={(e) => setExpiryMM(e.target.value)}
                  required
                >
                  <option value="month" disabled>
                    month
                  </option>
                  <option value="01">01</option>
                  <option value="02">02</option>
                  <option value="03">03</option>
                  <option value="04">04</option>
                  <option value="05">05</option>
                  <option value="06">06</option>
                  <option value="07">07</option>
                  <option value="08">08</option>
                  <option value="09">09</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                </select>
              </div>
              <div className="inputBox-payment">
                <span>expiration yy</span>
                <select
                  defaultValue="year"
                  name=""
                  id=""
                  placeholder="YY"
                  className="year-input-payment"
                  onChange={(e) => setExpiryYY(e.target.value)}
                  required
                >
                  <option value="year" disabled>
                    year
                  </option>
                  <option value="2021">2021</option>
                  <option value="2022">2022</option>
                  <option value="2023">2023</option>
                  <option value="2024">2024</option>
                  <option value="2025">2025</option>
                  <option value="2026">2026</option>
                  <option value="2027">2027</option>
                  <option value="2028">2028</option>
                  <option value="2029">2029</option>
                  <option value="2030">2030</option>
                </select>
              </div>
              <div className="inputBox-payment">
                <span>cvv</span>
                <input
                  type="password"
                  maxLength="3"
                  className="cvv-input-payment"
                  onChange={(e) => setCvv(e.target.value)}
                  required
                />
              </div>
            </div>
            <input
              type="submit"
              onClick={(e) => {
                handleBookSeats(e);
              }}
              value="submit"
              className="submit-btn-payment"
            />
          </form>
        </div>
      </div>
    </>
  );
};
