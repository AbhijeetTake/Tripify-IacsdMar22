import React from 'react'
import "../styles/footer_v2.css";
import '../styles/footer2css.css';
import '../styles/footer_new.css'
import SocialMedia from './SocialMedia'

const Footer_v2 = () => {
  return (
    <div className="footer">
      <div className="container-fluid fLists">
        <ul className="fList">
          <h3><u>Stay Connected</u></h3>
          <li className="fListItem">
          <p>Subscribe to get Email-Exclusive Coupouns.</p></li>
          <li className="fListItem">
          <input type="text" placeholder='Your Email Here' className='input-footer'/>
          <button className='input-btn' >Get Coupouns</button></li>
          <li className="fListItem">
          <div className='term-conditions-checkbox'>
            <input type="checkbox" />
            <p>By checking this box , I agree to get Updates </p>
          
          </div>
          </li>
          <li className="fListItem">
          <br/>
          <SocialMedia/>
          </li>

        </ul>
        <ul className="fList">
          <li className="fListItem"><h3><u>Company</u></h3> </li>
          <li className="fListItem">
          <span><ion-icon name="arrow-forward-outline"></ion-icon></span
          ><a href="#">Home</a>
          </li>
          <li className="fListItem">
          <span><ion-icon name="arrow-forward-outline"></ion-icon></span
          ><a href="#">About Us</a> 
          </li>
          <li className="fListItem">
          <span><ion-icon name="arrow-forward-outline"></ion-icon></span
          ><a href="#">FAQ'S</a>
          </li>
          <li className="fListItem">
          <span><ion-icon name="arrow-forward-outline"></ion-icon></span
          ><a href="#">Terms&Conditions</a>
          </li>
        </ul>
        <ul className="fList">
          <li className="fListItem"> <h3><u>Explore</u></h3> </li>
          <li className="fListItem">
          <p>
          <span><ion-icon name="call-outline"></ion-icon></span>
          <a href="tel:+919876543211"> EasyFlight </a>
          </p>
          </li>
          <li className="fListItem">
          <p>
          <span><ion-icon name="mail-outline"></ion-icon></span>
          <a href="#">
            Hotel
          </a>
          </p>
          </li>
          <li className="fListItem">
          <p>
          <span><ion-icon name="call-outline"></ion-icon></span>
          <a href="#"> Bundle </a>
          </p>
          </li>
        </ul>

      </div>
      <div className="fText">
      <hr/><br/><br/>
      <p>
      Copyright ©2022 All rights reserved | Developed with <span style={{color : "red"}}>❤</span> Abhyuday & Abhijeet
      </p>
      </div>
    </div>
  );
};

export default Footer_v2;
