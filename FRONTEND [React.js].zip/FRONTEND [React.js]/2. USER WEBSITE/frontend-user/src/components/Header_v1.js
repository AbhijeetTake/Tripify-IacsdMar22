import {  faBed,faCar,faPlane,faTaxi,faUser} from "@fortawesome/free-solid-svg-icons";
  import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
  import "../styles/Header_1.css";
  import { Link } from 'react-router-dom'
  import React, { useEffect,useState } from 'react'
  
  function Header_v1() {

    const [isLogin , setIsLogin] = useState({display : "none"})
    const [canRegister , setCanRegister] = useState({display : "flex"})

    useEffect(()=>{
      setIsLogin(localStorage.getItem("token") == undefined || null ? {display : "none"} : {display : "flex"}) 
      setCanRegister(localStorage.getItem("token") == undefined || null ? {display : "flex"} : {display : "none"})
    },[])

    return (
      <div>
        
        <div className="header">
      <div className="headerContainer">

        <div className="headerList">

          <div className="headerListItem header-logo">
            <FontAwesomeIcon icon={faPlane} />
            <span>Tripify</span>
          </div>
          <div className="headerListItem">
            {/* <FontAwesomeIcon icon={faCar} />
            <span>Car rentals</span> */}
          </div>
          <div className="headerListItem ">
            {/* <FontAwesomeIcon icon={faBed} />
            <span>Attractions</span> */}
          </div>
          <div className="headerListItem ">
            {/* <FontAwesomeIcon icon={faTaxi} />
            <span>Airport taxis</span> */}
          </div>

          <div className="headerListItem header-login ">
            <FontAwesomeIcon icon={faUser} />
            <Link to='/login' className="login-button"><span >Login/SignUp</span></Link>
          </div>

          <div className="headerListItem header-login " style={canRegister}>
            <FontAwesomeIcon icon={faUser} />
            <Link to='/register' className="login-button"><span >Register</span></Link>
          </div>

          <div className="headerListItem header-login " style={isLogin}>
            <FontAwesomeIcon icon={faUser} />
            <span><Link to='/' onClick={() => {localStorage.clear();sessionStorage.clear()}} 
            style={{
              textDecoration: "none",
              fontSize: "2rem",
              fontWeight:"bold",
              color: "#fff",
              // marginLeft: "3.5rem",
              // marginRight:"3.5rem",
              // border: "2px solid black",
              // paddingLeft:"1rem",
              // paddingRight:"1rem",
            }}>Logout</Link></span>
          </div>

        </div>
        </div>
        </div>     

      </div>
    )
  }
  
  export default Header_v1