import React from "react"
import { useEffect,useState } from "react"
import axios from "axios"



export default function Table({ list, total }) {

  const Final_Booking = JSON.parse(sessionStorage.getItem("Final_Booking"))
  const [name , setName ] = useState("")
  
  const invoice_Object = {
    Id : 0,
    Name : name,
    Class : Final_Booking.seat_type,
    Price : sessionStorage.getItem("currentFee"),   
    GST : Math.floor(sessionStorage.getItem("currentTax"))
  }

  const totalAmount = parseFloat(sessionStorage.getItem("currentFee") + parseFloat(sessionStorage.getItem("currentTax")))

  useEffect(() => {
    const id = localStorage.getItem("token")
    axios.get(`http://localhost:63301/api/Home?id=${id}`)
    .then(
      (Response) =>{
        setName(Response.data[0].First_name+" "+Response.data[0].Last_name)
          // console.log('Response.data = ' , Response.data[0]);
      }   
    ).catch(
      (err) => {
        console.log('Unable to get UserName ln 63:Invoice_Invoker');
      }
    )
  }, [])

  return (
    <>
      <table width="100%" className="mb-10">
        <thead>
          <tr className="bg-gray-100 p-1">
            <td className="font-bold">Description</td>
            <td className="font-bold">Quantity</td>
            <td className="font-bold">Class</td>
            <td className="font-bold">Price</td>
            <td className="font-bold">Amount(GST)</td>
          </tr>
        </thead>
        {
          <React.Fragment key={1}>
            <tbody>
              <tr className="h-10">
                <td>{invoice_Object.Name}</td>
                <td>{Final_Booking.seats}</td>
                <td>{invoice_Object.Class}</td>
                <td>{invoice_Object.Price}</td>
                <td>{invoice_Object.GST}</td>
              </tr>
            </tbody>
          </React.Fragment>
        }
      </table>

      <div>
        <h2 className="flex items-end justify-end text-gray-800 text-4xl font-bold">
          Rs. {Math.ceil(parseFloat(sessionStorage.getItem("currentFee")) + parseFloat(sessionStorage.getItem("currentTax")))}
        </h2>
      </div>
    </>
  )
}
