import React from 'react'
// import Email from 'emailjs';
// import emailjs from 'emailjs-com';

function EmailService() {

    const BookingObject = {
        Booking_ID: 1,
        Schedule_ID: 2,
        Name: "Sham Nayak",
        Source: "Benglaru(BLR)",
        Destination: "Ahmedabad (AMD)",
        FlightName: "Virgin",
        Distance: 1235,
        BusinessFee: 8555.55,
        EconomyFee: 4888.67,
        ClassType : "Economy",
        DepartureDate : "2022-02-02",
        DepartureTime: "15:08:50",
        SeatCount : 3
      }

    // const sendEmail = () =>  {
    //   Email.sendForm('gmail', 'template_cheom1d', BookingObject , 'pNYq9m15zDCL8hZdj')
    //     .then((result) => {
    //         console.log(result.text);
    //     }, (error) => {
    //         console.log(error.text);
    //     });
    // }

  return (
    <div>
        EmailService
        <button className='btn btn-primary btn-dark' > Click to Receive Email</button>
    </div>
    )

}

export default EmailService