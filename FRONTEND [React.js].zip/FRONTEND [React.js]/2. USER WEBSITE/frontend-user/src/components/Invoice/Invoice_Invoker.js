import React, { useState, useRef, useEffect } from "react"
import ClientDetails from "./ClientDetails"
import Dates from "./Dates"
import Footer from "./Footer"
import Header from "./Header"
import MainDetails from "./MainDetails"
import Notes from "./Notes"
import Table from "./Table"
import ReactToPrint from "react-to-print"
import axios from "axios"
import { useNavigate } from "react-router-dom"

// import EmailService from "./EmailService"

function Invoice_Invoker() {

  const [name, setName] = useState("Abhyuday Ghatale")
  const [address, setAddress] = useState("Amravati,Maharashtra,India")
  const [email, setEmail] = useState("dummyEmail@google.com")
  const [phone, setPhone] = useState("1234567891")
  const [bankName, setBankName] = useState("State Bank Of India")
  const [bankAccount, setBankAccount] = useState("9170 1000 0220 0319")
  const [website, setWebsite] = useState("www.Tripify.com")
  const [clientName, setClientName] = useState("Tripify(Flight Booking App)")
  const [clientAddress, setClientAddress] = useState("113 Gurudwara Rakabganj Road,New Delhi")
  const [invoiceNumber, setInvoiceNumber] = useState("544686433")
  const [seatNumber, setSeatNumber] = useState("S-7A")
  const [invoiceDate, setInvoiceDate] = useState("27 Sep 2022")
  const [dueDate, setDueDate] = useState("30 Sep 2022")
  const [notes, setNotes] = useState("Nothing to Display Currently")
  const [description, setDescription] = useState("Nothing to Display Currently")
  const [quantity, setQuantity] = useState("12")
  const [price, setPrice] = useState("35543")
  const [amount, setAmount] = useState("35645")
  const [list, setList] = useState([])
  const [total, setTotal] = useState(12030)
  const [classType, setClassType] = useState("Economy")
  const [getSource, setSourceName] = useState("PUNE(PNQ)")
  const [getDestination, setDestinationName] = useState("Benglaru(BLU)")
  const [width] = useState(641)
  const Navigate = useNavigate()
  const componentRef = useRef()

  /* Function call associated with Print Button on Page */
  const handlePrint = () => {
    window.print()
  }

  const NavigateToHomePage = ()=> {
      sessionStorage.clear()
      Navigate('/')
  }

  /* Gives an alert when browser width is less than certain range */
  useEffect(() => {
    if (window.innerWidth < width) {
      alert("Place your phone in landscape mode for the best experience")
    }
  }, [width])

  useEffect(() => {
    const id = localStorage.getItem("token")
    // console.log('localstorage ID = ' , id);
    axios.get(`http://localhost:63301/api/Home?id=${id}`)
    .then(
      (Response) =>{

              setName(Response.data[0].First_name+" "+Response.data[0].Last_name)
              setAddress(Response.data[0].Address)
              setEmail(Response.data[0].Email)
              setPhone(Response.data[0].Phone_nu)
              // sessionStorage.setItem("USER",JSON.stringify(Response.data[0]))
          // console.log('Response.data = ' , Response.data[0]);
      }   
    ).catch(
      (err) => {
        console.log('Unable to get UserName ln 63:Invoice_Invoker');
      }
    )
  }, [])


  return (
    <React.Fragment>
      
      <main className="m-20 p-5 xl:grid grid-cols-1 gap-10 xl:items-center">

        {/* Invoice Preview */}

        <div className="invoice__preview bg-white p-5 rounded">

          {/* npm install react-to-print */}
          {/* Ready-Made library : will implicitly calls print Functionality of Browser
              by passing only Essential Content that needs to be Printed  
          */}
          <ReactToPrint
            trigger={() => (
              <button className="bg-blue-500 ml-5 text-white font-bold py-2 px-8 rounded shadow border-2 border-blue-500 hover:bg-green-600 hover:text-blue-500 transition-all duration-300">
                Print / Download
              </button>
            )}
            content={() => componentRef.current}       />

              <button onClick={NavigateToHomePage} className="bg-blue-500 ml-5 text-white font-bold py-2 px-8 rounded shadow border-2 border-blue-500 hover:bg-green-600 hover:text-blue-500 transition-all duration-300">
                Go Back to HomePage
              </button>
          <div ref={componentRef} className="p-5">

            {/* INVOICER Header Component */}
            <Header/>

            {/* To Display Current User Details inside Invoice */}
            <MainDetails name={name} address={address} />

            {/* To Display Flight Client Details inside Invoice */}
            <ClientDetails
              clientName={clientName}
              clientAddress={clientAddress}
            />

            {/* To Display Invoice/Payment Info */}
            <Dates
              invoiceNumber={invoiceNumber}
              invoiceDate={invoiceDate}
              dueDate={dueDate}
            />

            {/* To Display Table-Rows of Passengers Info */}
            <Table
              description={description}
              quantity={quantity}
              price={price}
              amount={amount}
              list={list}
              setList={setList}
              total={total}
              class={classType}
              setTotal={setTotal}
            />

            {/* To Display Notes(Optional) in Invoice */}
            <Notes notes={notes} />

            {/* To Display Footer Info(General Info) inside Invoice */}
            <Footer
              name={name}
              address={address}
              website={website}
              email={email}
              phone={phone}
              bankAccount={bankAccount}
              bankName={bankName}
            />
          </div>
        </div>
      </main>

      {/* To Display Ticket Frame  */}
      {/* <Ticket/> */}

      {/* To Send Contents to User-Mail */}
      {/* <EmailService/> */}
    </React.Fragment>
  )
}

export default Invoice_Invoker
