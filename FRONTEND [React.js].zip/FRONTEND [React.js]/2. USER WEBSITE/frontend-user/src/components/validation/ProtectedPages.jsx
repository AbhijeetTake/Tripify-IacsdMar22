import React, { useEffect } from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export const ProtectedPages = ({ ValidatePage }) => {
  // useNavigate HOOK TO navigate user based on his correct credential
  const navigateTo = useNavigate();
  const [indicator , setIndicator] = useState(false)
  const [token , setToken] = useState() 

  const handleTokenValue = (check_token) => { 
    setToken(check_token);
    console.log('check_token => Login Page userid ' , token);
    setIndicator(true)
  }
  

  useEffect(() => {
    // GET KEY-VALUE FROM LOCALSTORAGE
    const check_token = localStorage.getItem("token");
    check_token == null || undefined
      ? navigateTo("/login")
      : handleTokenValue(check_token)
  },[]);

  return (
    <div>
      {/* ALL PAGES WILL BE SHOWN HERE */}
      { indicator && <ValidatePage />}
    </div>
  );
};
