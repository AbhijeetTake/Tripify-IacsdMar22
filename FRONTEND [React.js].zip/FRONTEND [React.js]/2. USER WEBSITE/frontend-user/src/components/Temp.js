import React,{useState} from 'react'

function Temp() {
    const { openRouterModal , setOpenRouterModal } = useState(false);
    console.log( "Value =  ", openRouterModal);
  return (
    <div>
    
    Temp JS

    </div>
  )
}

export default Temp