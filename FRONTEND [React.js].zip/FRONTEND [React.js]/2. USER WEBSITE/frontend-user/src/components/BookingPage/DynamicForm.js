import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from 'react-router-dom'
import '../../styles/BookingPage/DynamicForm.css'

function DynamicForm() {

  const Navigate = useNavigate()
  const [allPassengerInfo, setAllPassengerInfo] = useState([]);
  const [passengerCount, setPassengerCount] = useState(1);
  const [seatLimit, setSeatLimit] = useState(1);
  const [operation, setOperation] = useState(true);
  const [seatChosen, setSeatChosen] = useState([]);
  const [inputDisabled, setInputDisabled] = useState(0);
  const [currentPassenger, setCurrentPassenger] = useState({
    First_name: "",
    Last_name: "",
    Email: "",
    Phone_nu: "",
    Address: "",
  });

  useEffect(()=>{
    // const selectedScheduleInfo = JSON.parse(sessionStorage.getItem("selectedScheduleInfo"));\
    // selectedScheduleInfo != undefined || null ? setFinalBooking(selectedScheduleInfo)
    // : console.log("Couldn't able to retrieve FinalBooking from Session Storage");

    const getSeatLimit = JSON.parse(sessionStorage.getItem("selectedScheduleInfo"));
    getSeatLimit != undefined || null ? setSeatLimit(getSeatLimit.SeatsCount)
    : console.log(`Couldn't able to retrieve SeatsCount from Session Storage `, getSeatLimit);

    const getSeatChosen = JSON.parse(sessionStorage.getItem("seatChosen"));
    getSeatChosen != undefined || null ? setSeatChosen(getSeatChosen)
    : console.log(`Couldn't able to retrieve getSeatChosen from Session Storage `, getSeatChosen);

  },[])

  const submitRegistrationDetails = (e) => {
    if (passengerCount > seatLimit) {
      console.log("All Passengers Input Details Already Taken");
    } else {
      console.log('currentPassenger =>' , currentPassenger);
      const allPassenger = { ...currentPassenger };
      allPassengerInfo.push(allPassenger);
      setPassengerCount(passengerCount + 1);
      setCurrentPassenger({
        First_name: "",
        Last_name: "",
        Email: "",
        Phone_nu: "",
        Address: "",
      });
      console.log('allPassenger =>' , allPassengerInfo);

      // toast.success("Flight sucessfully UPDATED✨");
      alert("User Details Added")

    }
    e.preventDefault();
  };

  const handleInputChangeEvent = (e) => {
    const newDataItem = { ...currentPassenger };
    newDataItem[e.target.name] = e.target.value;
    setCurrentPassenger(newDataItem);
    // console.log('currentPassenger',currentPassenger);
  };

  const dynamicFormHtml = (count) => {
    return (
    <div>
    <div className="container">
    <div className="title">Travelers Info {count}</div>
    <div className="content">
      <form  onSubmit={(e)=>{submitRegistrationDetails(e)}}>
        <div className="user-details">
          <div className="input-box">
            <span className="details">First_name</span>
            <input type="text" placeholder="Enter your name" name="First_name" required onChange={(e) => handleInputChangeEvent(e)} ></input>
          </div>
          <div className="input-box">
            <span className="details">Last_name</span>
            <input type="text" placeholder="Enter your username" name="Last_name" required onChange={(e) => handleInputChangeEvent(e)} ></input>
          </div>
          <div className="input-box">
            <span className="details">EmailID</span>
            <input type="text" placeholder="Enter your email" name="Email" required onChange={(e) => handleInputChangeEvent(e)} ></input>
          </div>
          <div className="input-box">
            <span className="details">Phone Number</span>
            <input type="text" placeholder="Enter your number" name="Phone_nu" required onChange={(e) => handleInputChangeEvent(e)} ></input>
          </div>
          <div className="input-box Address">
            <span className="details">Address</span>
            <input type="text" placeholder="Enter your password" name="Address" required onChange={(e) => handleInputChangeEvent(e)} ></input>
          </div>
        </div>
        <div className="button">
          <input type="submit" value="Add Passenger Details" ></input>
        </div>
      </form>
    </div>
  </div>
  </div>
    );
  };

  const handleFormsPerPassenger = (count) => {
    let array  = [];
    for(var i=1;i<=count;i++){
        array.push(dynamicFormHtml(i))
    }
    return array;
  }

  const handleBuyTicketsProcess = (e) => {

    const selectedScheduleInfo = JSON.parse(sessionStorage.getItem("selectedScheduleInfo"));
    selectedScheduleInfo != undefined || null ? setOperation(true)
    : setOperation(false);


    if(operation == true){
      const currSeatChosen = JSON.parse(sessionStorage.getItem("seatChosen"))
      const Final_Booking = {
        "schedule_id": selectedScheduleInfo.scheduleItem.Schedule_ID ,
        "seat_type": selectedScheduleInfo.ClassType,
        "seats": selectedScheduleInfo.SeatsCount,
        "user_id" : localStorage.getItem("token"),
        "departure_date": selectedScheduleInfo.scheduleItem.DepartureDate,
        seatsChosen : currSeatChosen != undefined || null ? currSeatChosen : seatChosen ,
        passenger_collection : allPassengerInfo
      }
      sessionStorage.setItem('Final_Booking',JSON.stringify(Final_Booking))
      // handleBookSeats(Final_Booking)

      Navigate('/payment')
    }else{
      alert("Couldn't able to retrieve Selected Schedule from Session Storage")
    }
    // e.preventDefault()
  }


  return (
    <>
    {/* Prints Number of Forms Based on SeatLimits  */}
    {handleFormsPerPassenger(seatLimit)}

    <div className="submit-button">
    <button onClick={handleBuyTicketsProcess}>Proceed to Buy</button>
    </div>
    {/* <ToastContainer theme="colored" autoClose={1500} /> */}
    </>

  );
}

export default DynamicForm;
