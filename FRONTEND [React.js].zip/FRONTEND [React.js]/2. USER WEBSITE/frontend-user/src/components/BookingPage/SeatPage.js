import '../../styles/BookingPage/BookingPage.css'
import React, { useEffect, useState } from "react";
import Ticket from '../../components/ticket/ticket/Ticket';
import DynamicForm from './DynamicForm';


function SeatPage() {

    const [ seatLimit , setSeatLimit ] = useState(1)
    const [ seatCount , setSeatCount ] = useState(1)
    const [ isDisable , setIsDisable ] = useState(false)
    const [ seatLists , setSeatLists ] = useState([])

    useEffect(()=>{
      const getSeatLimit = JSON.parse(sessionStorage.getItem("selectedScheduleInfo"));
      getSeatLimit != undefined || null ? setSeatLimit(getSeatLimit.SeatsCount)
      : console.log(`Couldn't able to retrieve SeatsCount from Session Storage`, getSeatLimit);
  
    },[])

    const handleChangeInput = (e) => {
        if(seatCount <= seatLimit){
            seatLists.push(e.target.id)
            seatCount == seatLimit ? setIsDisable(true) : console.log();
            setSeatCount(seatCount+1)
            seatCount == seatLimit ? setIsDisable(true) : console.log();

            sessionStorage.setItem("seatChosen" , JSON.stringify(seatLists))
        }
        console.log(e.target.id);
    }

    const handleClearList = () => {
        setSeatLists([])
        setIsDisable(false)
        setSeatCount(1)
    }

    const getSeatChosenString = () => {
        var seatInputs = "";
        seatLists.map(
            element =>  {
                seatInputs += element + " "    
            })
        return (
        <>
        <span>{seatInputs}</span>
        </>    
        );
    }

  return (
    <div>
      {/* To Display Ticket Frame  */}
      <Ticket/>
      
      <div class="plane">
        <div class="cockpit">
          <h1>Please select a seat</h1>
        </div>
        <div class="exit exit--front fuselage"></div>
        <div className='seats-chosen'>
        {getSeatChosenString()}
        </div>
        <ol class="cabin fuselage">
          <li class="row row--1">
            <ol class="seats" type="A">
              <li class="seat">
                <input type="checkbox" id="1A" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="1A">1A</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="1B" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="1B">1B</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="1C" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="1C">1C</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="1D" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="1D">1D</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="1E" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="1E">1E</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="1F" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="1F">1F</label>
              </li>
            </ol>
          </li>
          <li class="row row--2">
            <ol class="seats" type="A">
              <li class="seat">
                <input type="checkbox" id="2A" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="2A">2A</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="2B" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="2B">2B</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="2C" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="2C">2C</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="2D" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="2D">2D</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="2E" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="2E">2E</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="2F" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="2F">2F</label>
              </li>
            </ol>
          </li>
          <li class="row row--3">
            <ol class="seats" type="A">
              <li class="seat">
                <input type="checkbox" id="3A" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="3A">3A</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="3B" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="3B">3B</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="3C" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="3C">3C</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="3D" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="3D">3D</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="3E" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="3E">3E</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="3F" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="3F">3F</label>
              </li>
            </ol>
          </li>
          <li class="row row--4">
            <ol class="seats" type="A">
              <li class="seat">
                <input type="checkbox" id="4A" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="4A">4A</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="4B" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="4B">4B</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="4C" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="4C">4C</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="4D" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="4D">4D</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="4E" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="4E">4E</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="4F" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="4F">4F</label>
              </li>
            </ol>
          </li>
          <li class="row row--5">
            <ol class="seats" type="A">
              <li class="seat">
                <input type="checkbox" id="5A" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="5A">5A</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="5B" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="5B">5B</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="5C" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="5C">5C</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="5D" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="5D">5D</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="5E" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="5E">5E</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="5F" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="5F">5F</label>
              </li>
            </ol>
          </li>
          <li class="row row--6">
            <ol class="seats" type="A">
              <li class="seat">
                <input type="checkbox" id="6A" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="6A">6A</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="6B" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="6B">6B</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="6C" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="6C">6C</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="6D" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="6D">6D</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="6E" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="6E">6E</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="6F" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="6F">6F</label>
              </li>
            </ol>
          </li>
          <li class="row row--7">
            <ol class="seats" type="A">
              <li class="seat">
                <input type="checkbox" id="7A" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="7A">7A</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="7B" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="7B">7B</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="7C" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="7C">7C</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="7D" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="7D">7D</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="7E" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="7E">7E</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="7F" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="7F">7F</label>
              </li>
            </ol>
          </li>
          <li class="row row--8">
            <ol class="seats" type="A">
              <li class="seat">
                <input type="checkbox" id="8A" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="8A">8A</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="8B" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="8B">8B</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="8C" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="8C">8C</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="8D" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="8D">8D</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="8E" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="8E">8E</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="8F" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="8F">8F</label>
              </li>
            </ol>
          </li>
          <li class="row row--9">
            <ol class="seats" type="A">
              <li class="seat">
                <input type="checkbox" id="9A" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="9A">9A</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="9B" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="9B">9B</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="9C" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="9C">9C</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="9D" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="9D">9D</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="9E" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="9E">9E</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="9F" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="9F">9F</label>
              </li>
            </ol>
          </li>
          <li class="row row--10">
            <ol class="seats" type="A">
              <li class="seat">
                <input type="checkbox" id="10A" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="10A">10A</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="10B" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="10B">10B</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="10C" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="10C">10C</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="10D" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="10D">10D</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="10E" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="10E">10E</label>
              </li>
              <li class="seat">
                <input type="checkbox" id="10F" onChange={(e) => handleChangeInput(e)} disabled={isDisable}/>
                <label for="10F">10F</label>
              </li>
            </ol>
          </li>
        </ol>
        <button className='seats-clear' onClick={handleClearList}>clear</button>
        <div class="exit exit--back fuselage"></div>
      </div>

    <DynamicForm/>

    </div>
  );
}

export default SeatPage;
