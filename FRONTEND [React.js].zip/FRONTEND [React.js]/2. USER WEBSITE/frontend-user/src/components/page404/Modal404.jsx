import React, { useState } from "react";
import { createPortal } from "react-dom";
import { ImEarth } from "react-icons/im";
// import error from "../../assets/images/error404.gif";
import Login_Page from "../Login_Page";
import { NavLink } from "react-router-dom";

// moon & star css in NoMatch.css file
import "./Modal404.css";
function Modal404() {
  const [openModel, setOpenModel] = useState(true);
  // checking "open model/popup = true or false USING TERNARY OPERATOR"
  const showPopup = openModel ? (
    <div id="popup404-container">
      <div id="popup404">
        <div>
          <div className="moon"></div>
          <div className="moon__crater moon__crater1"></div>
          <div className="moon__crater moon__crater2"></div>
          <div className="moon__crater moon__crater3"></div>

          <div className="star star1"></div>
          <div className="star star2"></div>
          <div className="star star3"></div>
          <div className="star star4"></div>
          <div className="star star5"></div>
          <div className="star star6"></div>
          <div className="star star7"></div>
          <div className="star star8"></div>
          <div className="star star9"></div>

          <div className="error">
            <div className="error__title">404</div>
            <div className="error__subtitle">Hmmm...</div>
            <div className="error__description">
              Searching for the moon...!!
            </div>
            
            <NavLink
              id="link"
              to="/"
              element={<Login_Page />}
              className="error__button error__button--active"
              style={{
                paddingLeft : "10px"
              }}
            >
              <span>
                Go Back to Earth
              </span>
            
            </NavLink>
          </div>
  
          <div className="astronaut">
            <div className="astronaut__backpack"></div>
            <div className="astronaut__body"></div>
            <div className="astronaut__body__chest"></div>
            <div className="astronaut__arm-left1"></div>
            <div className="astronaut__arm-left2"></div>
            <div className="astronaut__arm-right1"></div>
            <div className="astronaut__arm-right2"></div>
            <div className="astronaut__arm-thumb-left"></div>
            <div className="astronaut__arm-thumb-right"></div>
            <div className="astronaut__leg-left"></div>
            <div className="astronaut__leg-right"></div>
            <div className="astronaut__foot-left"></div>
            <div className="astronaut__foot-right"></div>
            <div className="astronaut__wrist-left"></div>
            <div className="astronaut__wrist-right"></div>

            <div className="astronaut__head">
              <div className="astronaut__head-black">.</div>
              <div className="astronaut__head-visor-flare1"></div>
              <div className="astronaut__head-visor-flare2"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  ) : null;
  //   INSTEAD OF JUST SIMPLY RETURNING JSX we return this JSX at another dom-node
  //   i.e here at element with id:portal-for-popup
  return createPortal(
    showPopup,
    document.getElementById("portal-for-popup404")
  );
}

export default Modal404;

//  {/* <div classNameName="container-404"> */}
//  <h1 id="title-404">4 0 4</h1>
//  <img id="error404-img" src={error} alt="404 gif" />
//  <div id="typo">
//    <h2>
//      I may have Unplugged the <span id="clr">power cord</span>.
//    </h2>
//    <p>Page you are looking for is not available!</p>
//    <NavLink
//      id="link"
//      to="/"
//      element={<HomePage />}
//      onClick={() => setOpenModel(false)}
//    >
//      Back to homepage
//    </NavLink>
//  </div>
//  {/* </div> */}
