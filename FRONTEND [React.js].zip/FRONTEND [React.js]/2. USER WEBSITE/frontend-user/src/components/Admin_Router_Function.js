import React, { useEffect, useState } from 'react'
import axios from 'axios'
import '../App.css';
import '../styles/router.css'
import Router_Popup from './Router_Popup';
import Router_UpdatePop from './Router_UpdatePop';

function Admin_Router_Function() {

const [ routes , setRoutes] = useState([])
const [ itemById , setItemByID] = useState({ Route_id : 0 , Source : '' , Destination : '' , Distance : '' })
const [ openRouterModal , setOpenRouterModal ] = useState(false);
const [ openRouterUpdateModal , setOpenRouterUpdateModal ] = useState(false);

  useEffect (() => {
  callGetAllRoutesAPI()
},[routes.length])

const callGetAllRoutesAPI = () => {
  //fetch data from API
  axios.get('http://localhost:63301/api/Routes')
  .then(
      (response) => { 
          console.log(response.data);
          setRoutes(response.data)
      }
  ).catch(
      (err)=> console.error(err)
  )
}

const handleRouterDelete = (id) => {

  alert(`Deleting this ID: ${id}`)
  const delAPI = `http://localhost:63301/api/routes/${id}`
  axios.delete(delAPI)
  .then(
      (response) => console.log(response , alert('Successfully Deleted') , callGetAllRoutesAPI() )
  ).catch(
      (err) => console.log(err , alert('Operation Failed'))
  )
}

const handleRouterUpdate = (id) => {
  alert(`Update this ID: ${id}`)

  const getByIdAPI = `http://localhost:63301/api/Routes/${id}`
  axios.get(getByIdAPI)
  .then(
      (res) => { 
        setItemByID(res.data) 
        setOpenRouterUpdateModal(true)
      } 
  ).catch(
      (err) => console.log(err , alert(' \nFailed Retrieved By ID'))
  )
}

let lists = routes.map((item) => {
  return (
      <tr key={item.Route_id}>
      <td>{item.Route_id}</td>
      <td>{item.Source}</td>
      <td>{item.Destination}</td>
      <td>{item.Distance}Km</td>
      <td>{item.Created_date}</td>
      <td>
       <button onClick={() => handleRouterDelete(item.Route_id)} className='btn btn-danger btn-sm router-btn'>Delete</button>
       <button onClick={() => handleRouterUpdate(item.Route_id)} className='btn btn-primary btn-sm router-btn'>Update</button>
      </td>
      </tr>
  )      
})

  return (

    <div className='container router-root'>
    <div className='router-div'>
    <h2>Administrator DashBoard</h2>
    <div className='new-routes-bar'>
        <p>All Routes</p>
        <button className='btn btn-info add-routes' id='' onClick={ () => { setOpenRouterModal(true)  } } > Add new Routes </button>
        { openRouterModal && <Router_Popup closeModal={setOpenRouterModal} items={setRoutes} /> }
        { openRouterUpdateModal &&  <Router_UpdatePop item={itemById} closeModal={setOpenRouterUpdateModal} items={setRoutes}/> }
    </div>
    <div className='search-bar-router'>
        <div >            
            <label>Show </label>
            <select className="custom-select mr-sm-2" id="inlineFormCustomSelect" defaultValue={100}>
            <option value="100">100</option>
            <option value="50">50</option>
            <option value="20">20</option>
            </select>
            <label> entries</label>
        </div>

        <div>
            <form className='form-inline'>
            <input className="form-control mr-sm-3" type="search" placeholder="Search" aria-label="Search" maxLength={15} max={20}/>
            <button className="btn btn-success btn-search" type="submit">Search</button>
            </form>
        </div>
    </div>

    <br/>
    <table className='table table-bordered'>
        <thead>
            <tr>
                <th>ID</th>
                <th>Source</th>
                <th>Destination</th>
                <th>Distance</th>
                <th>Created_Date</th>
            </tr>
        </thead>

        <tbody>
            {lists}
        </tbody>
    </table>
    </div>
  </div>

  )
}

export default Admin_Router_Function