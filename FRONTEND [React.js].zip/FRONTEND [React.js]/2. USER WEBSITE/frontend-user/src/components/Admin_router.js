{ /*
import React, { Component } from 'react'
import axios from 'axios'
import '../App.css';
import '../styles/router.css'
import "../styles/Router-Modal.css";

// import Router_PopHandler from './Router_PopHandler';

class Admin_router extends Component {

 constructor(props) {
   super(props)
 
   this.state = {
      routes : []
   }
   this.callGetAllRoutesAPI = this.callGetAllRoutesAPI.bind(this)
   
 }


 callGetAllRoutesAPI() {
    //fetch data from API
    axios.get('http://localhost:63301/api/Routes')
    .then(
        (response) => { 
            console.log(response.data);
            this.setState({
                routes : response.data
            })
        
        }
    ).catch(
        (err)=> console.error(err)
    )
 }

 handleRouterDelete = (id) => {

    alert(`Deleting this ID: ${id}`)
    const delAPI = `http://localhost:63301/api/routes/${id}`
    axios.delete(delAPI)
    .then(
        (response) => console.log(response , alert('Successfully Deleted') , this.callGetAllRoutesAPI() )
    ).catch(
        (err) => console.log(err , alert('Operation Failed'))
    )
 }
 
 handleRouterUpdate = (id) => {
    alert(`Update this ID: ${id}`)
}


 componentDidMount() {
    this.callGetAllRoutesAPI()
 }

 componentDidUpdate() {
    
 }

  render() {
    let lists = this.state.routes.map((item) => {
        return (
            <tr key={item.Route_id}>
            <td>{item.Route_id}</td>
            <td>{item.Source}</td>
            <td>{item.Destination}</td>
            <td>{item.Distance}Km</td>
            <td>{item.Created_date}</td>
            <td>
             <button onClick={() => this.handleRouterDelete(item.Route_id)} className='btn btn-danger btn-sm router-btn'>Delete</button>
             <button onClick={() => this.handleRouterUpdate(item.Route_id)} className='btn btn-primary btn-sm router-btn'>Update</button>
            </td>
            </tr>
        )      
    })
    return (
      <div className='container router-root'>
        <div  className='router-div'>
        <h2>Administrator DashBoard</h2>
        <div className='new-routes-bar'>
            <p>All Routes</p>
            <button className='btn btn-info' onClick={()=> this.Router_Modal() } > Add new Routes </button>
            
        </div>
        <div className='search-bar-router'>
            <div >            
                <label>Show </label>
                <select className="custom-select mr-sm-2" id="inlineFormCustomSelect" defaultValue={100}>
                <option value="100">100</option>
                <option value="50">50</option>
                <option value="20">20</option>
                </select>
                <label> entries</label>
            </div>

            <div>
                <form className='form-inline'>
                <input className="form-control mr-sm-3" type="search" placeholder="Search" aria-label="Search" maxLength={15} max={20}/>
                <button className="btn btn-success btn-search" type="submit">Search</button>
                </form>
            </div>



        </div>

        <br/>
        <table className='table table-bordered'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Source</th>
                    <th>Destination</th>
                    <th>Distance</th>
                    <th>Created_Date</th>
                </tr>
            </thead>

            <tbody>
                {lists}
            </tbody>
        </table>

        </div>
      </div>
    )
  }
}

export default Admin_router

*/ }