import React, { useState, useEffect } from "react";
import "./Ticket.css";
import { IoIosAirplane } from "react-icons/io";
import { DateFormatConverter } from "../../../utils/DateFormatConverter";

function Ticket() {

  // const [currTicketData,setTicketData] = useState([])
  
  // useEffect(
  //   () => {
  //     const ticket = JSON.parse(sessionStorage.getItem("selectedScheduleInfo"))
  //     ticket != undefined || null ? currTicketData.push(ticket)
  //     : console.log(`Couldn't able to retrieve ticket from Session Storage`, ticket);    
  //   },[]
  // )


  // let ticketData = currTicketData[0]

  const ticketData = JSON.parse(sessionStorage.getItem("selectedScheduleInfo"))

  console.log('ticket from Session Storage -> ' , ticketData);

  return (
    <div className="ticket-container">
      {/* -------- write below : COL-1---------------- */}
      <div className="barcode-sect"></div>

      {/* -------- write below : COL-2 ----------------*/}
      <div className="tk-main-sect">
        {/* === main section row-1 ===*/}
        <div className="tk-main-content row-1">
          {/* passenger name */}
          <div>
            <div className="tk-mid-title">CLASS</div>
            <span className="blackFont">{ticketData.ClassType}</span>
          </div>

          {/* flight name */}
          <div>
            <div className="tk-mid-title">FLIGHT ID</div>
            <span className="tk-value">
              {ticketData.scheduleItem.Flight_ID}
            </span>
          </div>

          {/* dept date */}
          <div>
            <div className="tk-mid-title">DATE</div>
            <span className="tk-value">
              <DateFormatConverter
                date={ticketData.scheduleItem.DepartureDate}
              />
              {/* {ticketData.scheduleItem.DepartureDate} */}
            </span>
          </div>

          {/* seat nu */}
          <div>
            <div className="tk-mid-title">SEATS</div>
            <span className="tk-value">{ticketData.SeatsCount}</span>
          </div>
        </div>

        {/* === main section row-2 === */}
        <div className="tk-main-content row-2">
          <h2>{ticketData.scheduleItem.Source}</h2>
          {/* <h3>icon-here</h3> */}
          <IoIosAirplane size="50px" />
          <h2>{ticketData.scheduleItem.Destination}</h2>
        </div>

        {/* ===  main section row-3 === */}
        <div className="tk-main-content row-3">
          <span>HAPPY JOURNEY</span>
          <span>GATE CLOSES 40 MINUTES BEFORE DEPARTURE</span>
        </div>
      </div>

      {/* -------- write below : COL-3---------------- */}
      <div className="short-info-sect">
        {/* row-1 */}
        <div id="right-row1"></div>
        {/* row-2 */}
        <div id="right-row2">
          {/* row-2-col-1 */}
          <div id="rt-row2-col1">
            <div>
              <div className="tk-right-title">CLASS</div>
              <span>{ticketData.ClassType}</span>
            </div>

            <div>
              <div className="tk-right-title">FLIGHT ID</div>
              <span>{ticketData.scheduleItem.Flight_ID}</span>
            </div>

            <div>
              <div className="tk-right-title">DATE</div>
              <span>
                <DateFormatConverter
                  date={ticketData.scheduleItem.DepartureDate}
                />
              </span>
            </div>

            <div>
              <div className="tk-right-title">SEATS</div>
              <span>{ticketData.SeatsCount}</span>
            </div>
          </div>
          {/* row-2-col-2 */}
          <div className="rt-row2-col2">
            <span>{ticketData.scheduleItem.Source}</span>
            <IoIosAirplane size="20px" style={{ transform: "rotate(90deg)" }} />
            <span>{ticketData.scheduleItem.Destination}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Ticket;
