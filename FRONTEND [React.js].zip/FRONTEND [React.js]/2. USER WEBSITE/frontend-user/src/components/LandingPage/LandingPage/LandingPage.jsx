import React from "react";
import "./LandingPage.css";
import earth from "./earth1.png";
import { BsCaretRightFill } from "react-icons/bs";
import { Link } from "react-router-dom";

export const LandingPage = () => {
  return (
    <>
      <div id="landing-hero-section">
        <div id="left-1">
          <div className="hero-heading">Explore a</div>
          <span className="hero-heading text-2">new world.</span>
          <p id="hero-sm-text1">
            No matter where in the world you want to go,{" "}
          </p>
          <p id="hero-sm-text2">we can help you get there.</p>
          <div id="btn-hero">
            <Link to="/schedules">
              <span>
                start planning{" "}
                <BsCaretRightFill style={{ paddingTop: "2px" }} />
              </span>
            </Link>
          </div>
        </div>
        <div id="left-2">
          <img src={earth} id="earth-img" />
        </div>
        <div id="glass-ld"></div>
      </div>
    </>
  );
};
