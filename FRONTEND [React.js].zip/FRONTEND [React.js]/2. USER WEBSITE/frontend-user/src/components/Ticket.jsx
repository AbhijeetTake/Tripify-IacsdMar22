import React from "react";
import "../styles/Ticket.css";

function Ticket({}) {
  return (
    <div className="tk-container">
      {/* -------- write below ---------------- */}
      <div className="box">
        <div>Tripify Airlines </div>
      </div>

      {/* -------- write below ----------------*/}
      <div className="box dots">Tripify Airlines</div>

      <div className="box">
        {/* -------- write below 3 div columns ---------------- */}
        <div className="container-col">

        <div>Tripify Airlines </div>
        <div>Tripify Airlines </div>
        <div>Tripify Airlines </div>
        
        </div>
        <div className="container-col">passenger details</div>
        <div className="container-col">boardingtime</div>
      </div>

      <div className="box dots">
        {/* -------- write below 1 column---------------- */}
        <div className="container-col">short info</div>
      </div>
    </div>
  );
}

export default Ticket;
