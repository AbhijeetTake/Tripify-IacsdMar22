import React from 'react'

function NotFound() {
  return (
    <h1 style={{color: "white"}}> 404! NotFound </h1>
  )
}

export default NotFound