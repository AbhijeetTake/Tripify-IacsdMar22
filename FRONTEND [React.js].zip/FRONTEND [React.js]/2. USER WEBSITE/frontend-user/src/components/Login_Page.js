import React, { useState } from 'react'
import bgImg from '../assets/img1.jpg';
// import bgImg2 from '../assets/istockphoto-1395375569-170667a.jpg';
import '../Resources/css/form_login.css'
import axios from 'axios';
import { useNavigate } from 'react-router-dom'

function Login_Page() {

    const Navigate = useNavigate()
    const [ form_Message , setForm_Message ] = useState("")
    const [ msgColor , setMsgColor ] = useState("Red")

    const [DataItem , setDataItem] = useState({
        User_id : '0',
        Email : '',
        Password : '',
        confirmpwd : '',
        Phone_nu : '',
        Address : 'TEMP-ADDRESS',
        Role : 'USER',
        returnUrl : "AboutUs"
    })

    // const setUserInformation = (user) => {

    //     console.log('Response from axios',user);
    //     const newUserItem = {...user}
    //     newUserItem["Email"] = user.Email;
    //     newUserItem["First_name"] = user.First_name;
    //     newUserItem["Last_name"]= user.Last_name;
    //     newUserItem["Phone_nu"] = user.Phone_nu;
    //     newUserItem["Address"] = user.Address;
    //     newUserItem["User_id"] = user.User_id;
    //     setUserInfo(user)
    //     console.log('created user state inside login',userInfo);
    // }

    const submitRegistrationDetails = (e) => {

        const LoginUrl = `http://localhost:63301/api/Home/`;
        axios.post(LoginUrl , DataItem)
        .then(
            (Response) => {
            console.log(Response.data)
            setForm_Message("Success")
            setMsgColor("Green")
            // setUserInformation(Response.data)
            console.log( 'token => ', Response.data.User_id);
            setTimeout(() => Navigate('/schedules'),1000)

            
            localStorage.setItem("token",Response.data.User_id);
        }
        ).catch(
            (Response) => {console.log(Response.data)
            setForm_Message("Invalid User Name or Password")
            }
        );

        e.preventDefault();

    }

    const handleInputChangeEvent = (e) => {
        const newDataItem = { ...DataItem }
        newDataItem[e.target.name] = e.target.value
        setDataItem(newDataItem)
      };


  return (
    <div className='App'>

        <div className="login">
            <div className="coll-1">
            <h2>Welcome to Tripify</h2>
            <span>Sign-In and Enjoy the Service</span>
                <form method="POST" id='form-login' className='flex flex-col-1' onSubmit={(e) => submitRegistrationDetails(e)}>
                    <input type="text" name="Email"  onChange={(e) => handleInputChangeEvent(e)} placeholder='emailID' />
                    <input type="password" name="Password"  onChange={(e) => handleInputChangeEvent(e)} placeholder='password' />
                    <button className='btn'>Sign-In</button>
                </form>
                <h5 style={{color : `${msgColor}`}}><br/>{form_Message}</h5>

            </div>
            <div className="col-3">
                <img  src={bgImg} alt="" />
            </div>
        </div>
    </div>
  )
}

export default Login_Page