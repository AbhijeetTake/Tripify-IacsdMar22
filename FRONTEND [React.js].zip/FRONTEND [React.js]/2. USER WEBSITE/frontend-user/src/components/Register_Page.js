import axios from 'axios';
import React, { useEffect, useState } from 'react'
import bgImg from '../assets/img1.jpg';
import bgImg2 from '../assets/istockphoto-1395375569-170667a.jpg';
// import { useForm } from 'react-hook-form';
import '../Resources/css/form_register.css'
import { useNavigate } from 'react-router-dom';

export default function Register() {

    const Navigate = useNavigate()

    const [DataItem , setDataItem] = useState({
        User_id : '1',
        First_name : '',
        Last_name : '',
        Email : '',
        Password : '',
        confirmpwd : '',
        Phone_nu : '',
        Address : 'TEMP-ADDRESS',
        Role : 'USER'
    })

    const submitRegistrationDetails = (e) => {

        const registerUrl = "http://localhost:63301/api/Home";

        console.log('dataItem = ' , DataItem);

        axios.post(registerUrl , DataItem)
        .then(
            (Response) => {
                console.log(Response.data)
                alert('User Registered Successfully')
                Navigate('/')
            }
        ).catch(
            (Response) => {
                console.log(Response.data)
                alert('User Failed to Register')
            }
        );

        e.preventDefault()

    }

    const handleInputChangeEvent = (e) => {
        const newDataItem = { ...DataItem }
        newDataItem[e.target.name] = e.target.value
        setDataItem(newDataItem)
      };



  return (
    <div className='App'>

        <div >

            <div className='Form-heading'>
                <section>            
                    <h1>Welcome to Tripify</h1>
                    <h2>Registration Page</h2>
                    <p>Create an Account or <a href="#">Log-in</a>. Sign-up to get specific benefits<br/></p>
                    <span>Register and Enjoy the Service</span></section>
            </div>

            <div className="register">
            <div  className="col-1">


                <form id='form' className='px-4 py-3 rounded-full' onSubmit={ (e) => submitRegistrationDetails(e)}>
                    <input type="text" name="First_name" onChange={(e) => handleInputChangeEvent(e)} placeholder='firstName' className='rounded text-pink-500' />
                    <input type="text" name="Last_name"  onChange={(e) => handleInputChangeEvent(e)} placeholder='lastName'  className='rounded text-pink-500'/>
                    <input type="email" name="Email"   onChange={(e) => handleInputChangeEvent(e)} placeholder='emailID'  className='rounded text-pink-500'/>
                    <input type="password" name="Password"   onChange={(e) => handleInputChangeEvent(e)} placeholder='password'  className='rounded text-pink-500'/>
                    <input type="password" name="confirmpwd" onChange={(e) => handleInputChangeEvent(e)}placeholder='confirm password'  className='rounded text-pink-500'/>
                    <input type="text" name="Phone_nu"   onChange={(e) => handleInputChangeEvent(e)} placeholder='mobile number'  className='rounded text-pink-500'/>
                    <input type="text" name="Address"   onChange={(e) => handleInputChangeEvent(e)} placeholder='address'  className='rounded text-pink-500'/>
                    <button className='btn btn-primary'>Create Account</button>
                </form>

            </div>
            <div className="col-2">
                <img src={bgImg2} alt="Flight IMG" />
            </div>
            </div>

        </div>
    </div>
  )
}
