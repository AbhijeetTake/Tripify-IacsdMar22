import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
    faYoutube,
    faFacebook,
    faTwitter,
    faInstagram
  } from "@fortawesome/free-brands-svg-icons";
import React from 'react'



function SocialMedia() {
  return (
    <div className='social-media-logo'>

    <a href="https://www.youtube.com/">
      <FontAwesomeIcon icon={faYoutube} size="2x" />
      &#160;&#160; 
      {/* Space symbols */}
    </a>
    <a href="https://www.facebook.com/">
      <FontAwesomeIcon icon={faFacebook} size="2x" />
      &#160;&#160;
    </a>
    <a href="https://www.twitter.com/" >
      <FontAwesomeIcon icon={faTwitter} size="2x" />
      &#160;&#160;
    </a>
    <a href="https://www.instagram.com/">
      <FontAwesomeIcon icon={faInstagram} size="2x" />
    </a>

  </div>
  )
}

export default SocialMedia

/*
className="youtube social"
className="facebook social"
className="twitter social"
className="instagram social"
*/